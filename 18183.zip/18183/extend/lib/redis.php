<?php
namespace lib;

class redis{
    protected static $handler = null;
    protected $options = [
        'host' => '127.0.0.1',
        'port' => 6379,
        'password' => '',
        'select' => 0,
        'timeout' => 0,   //关闭时间 0:代表不关闭
        'expire' => 0,
        'persistent' => false,
        'prefix' => '',
    ];

    public function __construct($options = []){
        if (!extension_loaded('redis')) {   //判断是否有扩展(如果你的apache没reids扩展就会抛出这个异常)
            throw new \BadFunctionCallException('not support: redis');
        }
        if (!empty($options)) {
            $this->options = array_merge($this->options, $options);
        }
        $func = $this->options['persistent'] ? 'pconnect' : 'connect';     //判断是否长连接
        self::$handler = new \Redis;
        self::$handler->$func($this->options['host'], $this->options['port'], $this->options['timeout']);

        if ('' != $this->options['password']) {
            self::$handler->auth($this->options['password']);
        }

        if (0 != $this->options['select']) {
            self::$handler->select($this->options['select']);
        }
    }

    /**
     * 写入缓存
     * @check string $key 键名
     * @check string $value 键值
     * @check int $exprie 过期时间 0:永不过期
     * @return bool
     */
    public function set($key, $value, $exprie = 0){
        if ($exprie == 0) {
            $set = self::$handler->set($key, $value);
        } else {
            $set = self::$handler->setex($key, $exprie, $value);
        }
        return $set;
    }

    public function del($key){
        return self::$handler->del($key);
    }

    /**
     * 读取缓存
     * @check string $key 键值
     * @return mixed
     */
    public function get($key){
        $fun = is_array($key) ? 'Mget' : 'get';
        return self::$handler->{$fun}($key);
    }



    /**
     * 检查给定 key 是否存在。
     */
    public function exists($key){
        return self::$handler->exists($key);
    }


    //redis 队列
    /**
     * 获取值长度
     * @check string $key
     * @return int
     */
    public function lLen($key){
        return self::$handler->lLen($key);
    }

    /**
     * 将一个或多个值插入到列表
     * @check $key
     * @check $value
     * @return int
     */
    public function push($type,$key, $value){
        switch ($type) {
            case 1:
                return self::$handler->lPush($key, $value);
                break;
            case 2:
                return self::$handler->rPush($key, $value);
                break;
        }
    }

    /**
     * 移出并获取列表的元素
     * @check string $key
     * @return int
     */
    public function pop($type,$key){
        switch ($type){
            case 1:
                return self::$handler->lPop($key);
                break;
            case 2:
                return self::$handler->rPop($key);
                break;
        }
    }

    /**
     *获取列表指定范围内的元素
     */
    public function lRange($key,$start,$stop){
        return self::$handler->lRange($key,$start,$stop);
    }


    /**
     * 移除队列指定元素
     */
    public function lRem($key,$value,$count){
        return self::$handler->lRem($key,$value,$count);
    }

    /**
     * 通过索引获取列表中的元素
     */
    public function lIndex($key,$index){
        return self::$handler->lIndex($key,$index);
    }

    /**
     * 通过索引来设置元素的值
     */
    public function lSet($key,$index,$value){
        return self::$handler->lSet($key,$index,$value);
    }

    /**
     * 队列裁剪
     * @param $key
     * @param $start
     * @param $stop
     * @return array
     */
    public function ltrim($key, $start, $stop){
        return self::$handler->lTrim($key, $start, $stop);
    }


    //集合
    /**
     * 添加
     * @param $key
     * @param $value
     * @return int
     */
    public function sAdd($key, $value,$value2 = null, $valueN = null){
        return self::$handler->sAdd($key, $value, $value2, $valueN);
    }

    //元素是否在集合中
    public function sisMember($key,$member){
        return self::$handler->sIsMember($key,$member);
    }

    /**
     * @param $key
     * @return int
     * 返回集合元素个数
     */
    public function sCard($key){
        return self::$handler->sCard($key);
    }

    /**
     * @param $key
     * 返回集合中的所有成员
     */
    public function sMembers($key){
        return self::$handler->sMembers($key);
    }

    /**
     * 发布消息
     * @check $channel
     * @check $msg
     * @return int
     */
    public function publish($channel,$msg){
        return self::$handler->publish($channel,$msg);
    }

    /**
     * 订阅收到消息
     * @check $channel
     * @check $OAuth
     */
    public function subscribe($channel,$callback){
        self::$handler->subscribe(array($channel),$callback);
    }


    /**
     * 监控key,就是一个或多个key添加一个乐观锁
     * 在此期间如果key的值如果发生的改变，刚不能为key设定值
     * 可以重新取得Key的值。
     * @param unknown $key
     */
    public function watch($key){
        self::$handler->watch($key);
    }

    /**
     * 开启一个事务
     * 事务的调用有两种模式Redis::MULTI和Redis::PIPELINE，
     * 默认是Redis::MULTI模式，
     * Redis::PIPELINE管道模式速度更快，但没有任何保证原子性有可能造成数据的丢失
     */
    public function multi(){
        return self::$handler->multi();
    }

    /**
     * 执行一个事务
     * 收到 EXEC 命令后进入事务执行，事务中任意命令执行失败，其余的命令依然被执行
     */
    public function exec(){
        return self::$handler->exec();
    }
}