<?php
namespace lib;
use Elasticsearch\ClientBuilder;

class es{
    public $client = null;
    public $host=['localhost:9200'];
    public $index=null;  // 索引 (相当于数据库)
    public $type=null;   // 类型 (相当于数据库表格 table )
    public $pre=null;
    public function __construct($name) {
        $connect=ClientBuilder::create()->setHosts($this->host)->build();
        $this->client = $connect;
        $this->index=$name.'_index';
        $this->type=$name.'_type';
        $this->pre=$name;
        //索引是否存在
        $ex=$connect->indices()->exists([
            'index'=>$name.'_index'
        ]);
        if($ex==false){
            $this->index();
        };
    }

    //创建索引 （数据库）
    public function index(){
        $params = [
            'index' => $this->index,
            'body' => [
                'settings' => [
                    'number_of_shards' => 5, //分片
                    'number_of_replicas' => 0
                ]
            ]
        ];
        try {
            $this->client->indices()->create($params);
        } catch (\Elasticsearch\Common\Exceptions\BadRequest400Exception $e) {
            errorReturn(1020,$e->getMessage());
        }
    }

    // 删除索引(数据库)
    public function del_index() {
        $params = ['index' => $this->index];
        $this->client->indices()->delete($params);
    }

    //生成文档document (数据行)
    public function document($data){
        try{
            foreach ($data as $row) {
                $params = [
                    'body' => [
                        'id' => $row['id'],
                        'title' => $row['title'],
                        'content' => $row['detail'],
                    ],
                    'id' => $this->pre ."_".$row['id'],
                    'index' => $this->index,
                    'type' => $this->type
                ];
               $this->client->index($params);
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    // 获取单个文档
    public function get_doc($id) {
        $params = [
            'index' => $this->index,
            'type' => $this->type,
            'id' => $this->pre."_".$id
        ];
        return $this->client->get($params);
    }

    // 判断文档存在
    public function exists_doc($id) {
        $params = [
            'index' => $this->index,
            'type' => $this->type,
            'id' => $this->pre."_".$id
        ];
        return $this->client->exists($params);
    }

    // 更新文档(更新和删除 会修改版本号)
    public function update_doc($id,$up=[]){
        if($this->exists_doc($id)){
            $params = [
                'index' => $this->index,
                'type' => $this->type,
                'id' => $this->pre."_".$id,
                'body' => [
                    'doc'=> $up
                ]
            ];
            return $this->client->update($params);
        }else{
            errorReturn(1020,'文档不存在!');
        }
    }

    /*
    * 功能：查询条件
    */
    public function search($keywords,$word=[],$opt='or',$fitter=[],$order=""){
        $params = [
            'index' => 'articles_index',
            'type' => 'articles_type',

        ];

        //排序
        if($order!=false){
            //分页
            //$params['body']['size']=10;
            //$params['body']['from']=200;
            //排序
            $params['body']['sort']=[$order=>['order'=>'desc']];
        }

        //过滤查询 filter
        if(!empty($fitter)){
            $params['body']['query']['bool']['filter']=[
                "range"=>$opt
            ];
        }

        //多词匹配
        if(!empty($word)){
            if(count($word)>1){
                $con=$opt=='or' ? 'should' : 'must';
                $aop=[];
                //联合搜索  bool查询 must(and),should(or),must_not
                foreach ($word as $val){
                    array_push($aop,['match'=>[$val=>$keywords]]);
                };
                $params['body']['query']['bool'][$con]=$aop;
            }else{
                //单个字段匹配
                $con=$opt=='or' ? 'match' : 'match_phrase';
                $params['body']['query'][$con] =[$word[0]=>$keywords];
            }

            $response=$this->client->search($params);
            if($response['hits']['total']>0){
                $arr=[];
                foreach ($response['hits']['hits'] as $k=>$v){
                    array_push($arr,$v['_source']);
                }
                return $arr;
            }else{
                return [];
            }
        }
    }
}