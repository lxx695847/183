<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2019/7/23
 * Time: 14:42
 */
namespace lib;

class send{
    /**
     * 微信模板消息发送
     * @param $tem_id
     * @param $data
     * @param $openid
     * @return string
     */
    public function sendMsg($tem_id,$data,$openid){
            $appid = config('common.appid');
            $appsecret = config('common.appsecret');
            $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$appid."&secret=".$appsecret;
            //客户端是否缓存
//            if (cookie('access_token')){
//                $access_token =cookie('access_token');
//            }else{
                $json_token=http_curl($url,'post');
                $list=json_decode($json_token,true);
                $access_token = $list['access_token'];
//                setcookie('access_token',$access_token,7200);
//            }
            $params1 = json_encode($this->json_tempalte($tem_id,$data,$openid),JSON_UNESCAPED_UNICODE);
            $url="https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=".$access_token;
            $params = http_curl($url,'post',urldecode($params1));
            $row = json_decode($params,true);
            if ($row['errcode']==0){
                ajaxSuccess(205,'发送成功',['send success']);
            }else{
                ajaxError(405,$row['errmsg']);
            }
    }


    private function json_tempalte($tem_id,$data,$openid){
        $template=array(
            'touser'=>$openid,//openID
            'template_id'=>$tem_id,//模版id
            'url'=>$data['url'],
            'topcolor'=>"#7B68EE",
            'data'=>$data['content']
        );
        return $template;
    }
}