<?php
namespace lib;
use Upyun\Config;
use Upyun\Upyun;

class upyuns{
    protected $client;
    public $serviceConfig;
    public function __construct(){
        $this->serviceConfig = new Config('guangzi-video','guangzi','vbZoqxsKp39qTR2EyXVzLbrwhvca4pme');
        $this->client=new Upyun($this->serviceConfig);
    }

    //又拍云文件操作(上传)
    public function upyUploads($dir,$save_file_url){
        //要上传到哪个目录下
        $directory = $dir;
        $key = basename($save_file_url);
        if($directory){
            //真正使用时，$directory可能是用户传过来的，在不知道用户是否写了右斜杠的情况下，统一先去掉再添加一个
            $key = rtrim($directory, '/') . '/' . $key;
        }

        $file = fopen($save_file_url, 'r');
        if(filesize($save_file_url) > 15728640 && filesize($save_file_url) < 100*1024*1024){
            $this->serviceConfig->uploadType = 'BLOCK_PARALLEL';
        }else if(filesize($save_file_url) >= 100*1024*1024){
            return false;
        }else {
            return $this->client->write($key, $file);
        }
    }

    //是否有目录
    public function hasDir($path){
        return $this->client->has($path);
    }

    //删除文件
    public function deleteFile($path){
        return $this->client->delete($path);
    }

    //创建目录
    public function createDir($dir){
        return $this->client->createDir($dir);
    }

    //删除目录
    public function deleteDir($path){
        return $this->client->deleteDir($path);
    }
}