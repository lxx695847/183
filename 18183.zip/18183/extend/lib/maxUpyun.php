<?php
namespace lib;
use Upyun\Config;
use Upyun\Upyun;

class maxUpyun{
	const END_POINT = "http://v0.api.upyun.com";
	private $bucketname;
    private $username;
    private $password;
	private $ctimeout;

	public function __construct($bucketname, $username, $password, $ctimeout){

		$this->bucketname = $bucketname;
        $this->username = $username;
        $this->password = $password;
        $this->ctimeout = $ctimeout;
	}

	public function restupload($localpath, $savepath){
		$uri = "/{$this->bucketname}$savepath";
		$date = gmdate('D, d M Y H:i:s \G\M\T');
		$fsize = filesize($localpath);
		$signature = base64_encode(hash_hmac("sha1", "PUT&$uri&$date", md5("{$this->password}"), true));
		$header = array(
            "authorization:UPYUN {$this->username}:$signature",
            "Date:$date"
        );
		$fh = fopen($localpath,'rb');
		$ch = curl_init(self::END_POINT.$uri);
		curl_setopt($ch, CURLOPT_INFILE,$fh);
		curl_setopt($ch, CURLOPT_INFILESIZE, $fsize);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_TIMEOUT, "{$this->ctimeout}");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_exec($ch);
        $rsp_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		return $rsp_code;
	}
}

