<?php
namespace lib;

class Qcloud{
    public $bucket;
    protected $client;//存储桶名称，由BucketName-Appid 组成
    public function __construct(){
        $this->bucket='cms-1304856279';
        $this->client=new \Qcloud\Cos\Client([
            'region' => 'ap-guangzhou',
            'credentials' =>[
                'secretId' => 'AKIDQgfOs63kAJAk47tPecJjtmPlvoQlpdAQ',
                'secretKey' => '0jBMFsEK9hz1mGTQ6UbR0HH0NUKuDFzU'
            ]
        ]);
    }

    public function getUps($save,$read){
        try {
            $result = $this->client->upload(
                $bucket = $this->bucket,
                $key = $save, //此处的 key 为对象键
                $body = fopen($read, 'rb')
            );
            // 请求成功
            $data = $result->toArray() ;
            if(isset($data['Location']) && isset($data['Key'])) {
                return ['upload_success'=>true,'data'=>$data['Location']];
            }else{
                return ['upload_success'=>false,'data'=>'上传失败'];
            }
        } catch (\Exception $e) {
            // 请求失败
            return ['upload_success'=>false,$e->getMessage()];
        }
    }

    //删除对象
    public function getDelete($save){
          $this->client->deleteObject(array(
                'Bucket' => $this->bucket,
                'Key' => $save
          ));
    }

//    public function downLoad($save,$local_path){
//        $printbar = function($totalSize, $downloadedSize) {
//            printf("downloaded [%d/%d]\n", $downloadedSize, $totalSize);
//        };
//
//        try {
//            $result = $this->client->download(
//                $bucket = $this->bucket,
//                $key = $save,
//                $saveAs = $local_path,
//                $options= array(
//                    'Progress' => $printbar, //指定进度条
//                    'PartSize' => 10 * 1024 * 1024, //分块大小
//                    'Concurrency' => 5, //并发数
//                    'ResumableDownload' => true, //是否开启断点续传，默认为false
//                    'ResumableTaskFile' => 'tmp.cosresumabletask' //断点文件信息路径，默认为<localpath>.cosresumabletask
//                )
//            );
//            // 请求成功
//            dump($result);
//        } catch (\Exception $e) {
//            // 请求失败
//            echo($e);
//        }
//    }
}