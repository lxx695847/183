<?php
namespace lib;
use Qiniu\Auth as Auth;
use Qiniu\Storage\BucketManager;
use Qiniu\Storage\UploadManager;
vendor('Qiniu.autoload');

class qiniu{
    public $config;
    private $auth;
    public function __construct(){
       $this->config=config('qiniu');
       $this->auth=new Auth($this->config['ACCESSKEY'], $this->config['SECRETKEY']);
    }

    public function ups($save,$read,$type=1){
//      require_once APP_PATH . '/../vendor/qiniu/php-sdk/autoload.php';
      // 要上传图片的本地路径
//      $file = request()->file('file');
//      $filePath = $file->getRealPath();
//      $ext = pathinfo($file->getInfo('name'), PATHINFO_EXTENSION);  //后缀

      // 上传到七牛后保存的文件名
//      $key =substr(md5($file->getRealPath()) , 0, 5). date('YmdHis') . rand(0, 9999) . '.' . $ext;

      // 需要填写你的 Access Key 和 Secret Key
      $accessKey = $this->config['ACCESSKEY'];
      $secretKey = $this->config['SECRETKEY'];
      // 构建鉴权对象
      $auth = new Auth($accessKey, $secretKey);
      // 要上传的空间
      $bucket = $this->config['BUCKET'];
      $domain = $this->config['DOMAIN'];
      $token = $auth->uploadToken($bucket);

      // 初始化 UploadManager 对象并进行文件的上传
      $uploadMgr = new UploadManager();
      // 调用 UploadManager 的 putFile 方法进行文件的上传
      if($type==2){
            $resumeFile = 'progress.log';
            $version = 'v2';
            $partSize = 6 * 1024 * 1024;
            list($ret, $err) = $uploadMgr->putFile(
                $token, $save, $read, null, 'application/octet-stream',
                false, $resumeFile, $version,$partSize
            );
      }else{
          list($ret, $err) = $uploadMgr->putFile($token, $save, $read);
      }
      if ($err !== null) {
          errorReturn(1020,$err);
      } else {
          successReturn(200,'',$domain.$ret['key']);
      }
  }

    /**
     * 删除图片
     * @param $delFileName 要删除的图片文件，与七牛云空间存在的文件名称相同
     * @return bool
     */
    public function delimage($delFileName){
        // 配置
        $config = new \Qiniu\Config();
        // 管理资源
        $bucketManager = new BucketManager($this->auth, $config);
        // 删除文件操作
        $res = $bucketManager->delete($this->config['BUCKET'], $delFileName);
        if (is_null($res)) {
            return true;
        }
        return false;
    }
}