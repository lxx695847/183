<?php
namespace helper;
define('imageRoot','/www/wwwroot/cms/public/Uploads/thumbFile/');
use think\Image;

class Images{
    public $read;
    public $save;
    public $ext;
    public $ffmpeg;
    public $width=640;
    public $height=360;
    public function __construct($read,$save,$ext){
        $this->read=$read;
        $this->save=$save;
        $this->ext=$ext;
        $this->ffmpeg=\FFMpeg\FFMpeg::create(
            [
                'ffmpeg.binaries'  => '/usr/local/ffmpeg/ffmpeg',
                'ffprobe.binaries' => '/usr/local/ffmpeg/ffprobe'
            ]
        );
    }

    public function extCheck(){
        //图像格式
        $img_formats=[
           'png','jpg','jpeg','gif','webp','bmp','pcx','tif','tga','exif','fpx','svg','psd','cdr','pcd',
           'dxf','ufo','eps','ai','hdri','raw','wmf','flic','emf','ico','avif','apng'
        ];
        //视频格式
        $video_formats = [
            "mpeg","mp4", "mov", "wav", "avi", "dat", "flv", "3gp"
        ];
        //音频格式
        $audio_formats=['mp3','aac','ogg','wav','flac','ape','alac'];

        if(in_array($this->ext,$img_formats)){
            //图片格式
            if(in_array($this->ext,['png','jpg','jpeg'])){
                return '';
            }elseif ($this->ext=='gif'){
                //gd库处理
                $im=imagecreatefromgif($this->read);
                $outFile=imageRoot.$this->save.".png";  //生成图片路径
                imagepng($im,$outFile);
                return 'Uploads/thumbFile/'.$this->save.".png";
            }else{
                return $this->pdf2png2($this->read);
            }
        }elseif(in_array($this->ext,$video_formats)){
            //视频
            if($this->ext!='mp4'){
                $video = $this->ffmpeg->open($this->read);  //上传的文件地址
                $format = new \FFMpeg\Format\Video\X264();
                $newPath=imageRoot.$this->save.'.mp4'; //转换格式
                $video->save($format, $newPath);//转码
                return $this->videoAct($newPath);
            }else{
                return $this->videoAct($this->read);
            }
        }elseif (in_array($this->ext,$audio_formats)){
            //音频
            if($this->ext!='mp3') {
                $audio = $this->ffmpeg->open($this->read);  //上传的文件地址
                $format = new \FFMpeg\Format\Audio\Mp3();
                $newPath=imageRoot.$this->save.'.mp3';  //转换格式
                $audio->save($format, $newPath);//转码
                $this->videoAct($newPath);
            }else{
                return $this->videoAct($this->read);
            }
        }elseif ($this->ext=='pdf'){
            //pdf文件
            return $this->pdf2png2($this->read);
        }elseif(in_array($this->ext,['zip','rar'])){
            //zip
            return "Uploads/poster/zip.png";
        }else {
            //office文件
            $newSave=basename($this->read);
            $newName=explode(".",$newSave)[0];
            $this->officePdf();
            $newPath=imageRoot.$newName.".pdf";
            if(file_exists($newPath)){
                $res=$this->pdf2png2($newPath);
                if($res){
                    unlink($newPath);
                    return $res;
                }
            }else{
                return 'Uploads/poster/office.png';
            }
        }
    }

    //office 转成 pdf
    public function officePdf(){
        exec("soffice --headless --invisible --language=zh-CN --convert-to pdf ".$this->read." --outdir ./Uploads/thumbFile/");   //转成pdf
    }

    //音频转波形图片
    public function audioAct($read){
        try{
            $audio = $this->ffmpeg->open($read);
            $waveform = $audio->waveform($this->width, $this->height,['#00FF00']);
            $outFile=imageRoot.$this->save.".png";  //生成图片路径
            $waveform->save($outFile);
            return 'Uploads/thumbFile/'.$this->save.".png";
        }catch (\Exception $e){
            return 'Uploads/poster/audio.png';
        }
    }

    //视频转图片
    public function videoAct($read){
        try{
            $video = $this->ffmpeg->open($read);  //上传的文件地址
            //获取视频第一帧
            $outFile=imageRoot.$this->save.".png";  //生成图片路径
            $video->frame(\FFMpeg\Coordinate\TimeCode::fromSeconds(1))
                ->save($outFile);//提取第1秒的图像
            $image = Image::open($outFile);
            $image->thumb($this->width, $this->height,6)->save($outFile);  //缩略图
            return 'Uploads/thumbFile/'.$this->save.".png";
        }catch (\Exception $e){
            echo ($e->getMessage());
            return 'Uploads/poster/video.png';
        }
    }


     //pdf,其他规格图片文件，生成png首页缩略图
    public function pdf2png2($read){
            $im = new \Imagick($read);
            if($this->ext=='pdf' || $this->ext=='psd'){
                $im->setIteratorIndex(0);  //获取第一页
            }
            $im->setCompressionQuality(100);
            $im->setResolution(120,120);//设置分辨率 值越大分辨率越高

            $im->setImageFormat('png');
            $im->stripImage();  //去除图片信息
            $im->trimImage(0);//删除从图像边缘
            $im->enhanceImage(); //去噪点
            //scaleImage 缩放
            $im->thumbnailImage($this->width, $this->height,false);
            $outFile=imageRoot.$this->save.".png";  //生成图片路径
            if($im->writeImage($outFile)==true){
                return 'Uploads/thumbFile/'.$this->save.".png";
            }else{
                return 'Uploads/poster/default.png';
            }
    }
}