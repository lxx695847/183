<?php
namespace helper;
use lib\redis;
use think\Db;

class weChat {
    public $open='';

    /*
     * 调用签名方法,并验证消息
     */
    public function valid() {
        $echoStr = $_GET["echostr"];
        if ($this->checkSignature()) {
            echo $echoStr;
            exit;
        }
    }

    /*
     * 验证签名
     */
    private function checkSignature() {
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];
        $base=db('base')->find();

        $token = $base['token'];
        $tmpArr = array($token, $timestamp, $nonce);
        // use SORT_STRING rule
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode($tmpArr);
        $tmpStr = sha1($tmpStr);

        if ($tmpStr == $signature) {
            return true;
        } else {
            return false;
        }
    }

    /*
     * 自动回复消息
     */
    public function responseMsg() {
        //类似$_POST用法,接受xml格式的信息
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        if (!empty($postStr)) {
            //做安全防御用
            libxml_disable_entity_loader(true);
            //将xml信息转换为对象
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            //用户发送的消息类型判断
            if ($postObj->MsgType == 'event') {
                //判断事件类型
                if ($postObj->Event == 'subscribe') {
                    $arr=[
                        "等天等地等花开，终于等到您,希望您在这领礼包领到手软！\n",
                        "每天来逛一逛，领领礼包、看看最新的游戏资讯、快乐生活~\n\n",
                        "【礼包领取】\n",
                        "1、回复“游戏名+礼包”，获取游戏礼包领取口令。\n",
                        "2、回复对应的领取口令，根据提示完成验证即可领取相关礼包啦。\n\n",
                        "具体操作可参考下方礼包领取攻略\n",
                        "<a href='https://mp.weixin.qq.com/s?__biz=MzIwMjc3MDI0Mg==&mid=2247495852&idx=1&sn=9cff26802487d1ca1864be4b0bfe3253&chksm=96db2281a1acab979e64c83fa6446dffb858be1674b55ed5c473b360a8bf2c3fd0ca880ff3f0&token=397298424&lang=zh_CN#rd'>礼包领取攻略</a>"
                    ];
                    $content = implode('',$arr);
                    $this->textPush($content, $postObj);
                }
            }
            if ($postObj->MsgType == 'text') {
                //指令
                $keyWord=$postObj->Content;
                $content=$this->sendContent($keyWord,$postObj->FromUserName);
                $this->textPush($content, $postObj);
            }
            //判断消息类型
            $msg_type = trim($postObj->MsgType);
            switch ($msg_type) {
                case "text":    //文本消息
                    $result = $this->receiveText($postObj);
                    break;
                default:
                    $result = "未知的消息类型: " . $msg_type;
                    break;
            }
            echo $result;
        }
    }

    /*
     * 接收文本消息
     */
    private function receiveText($object) {
        $content = "你发送的是文本内容为：" . $object->Content;
        $result = $this->transmitText($object, $content);
        return $result;
    }

    public function sendContent($keyWord,$openid){
        $keyWord=trim($keyWord);
        $openid=trim($openid);
        $redis=new redis();
        $base=db('base')->where(['id'=>1])->find();
        $record1="'游戏名+礼包'";

        $default=[
            "不好意思，我们无法知晓您想要哪款游戏的礼包\n",
            "请回复".$record1."，获取游戏礼包领取口令\n",
            "如幻塔礼包，正确回复才能获取相应礼包哦~"
        ];

        if($keyWord=='礼包'){
            return implode('',$default);
        }elseif($keyWord=='口令' || $keyWord=='口令码'){
            return implode('',$default);
        }elseif($keyWord=='答案'){
            return implode('',$default);
        } elseif (mb_strpos($keyWord,'礼包')!==false){
            //游戏
            $keys=mb_substr($keyWord,0,mb_strpos($keyWord,'礼包'));
            $opt=[
                'show'=>2,
                'effectStart'=>['elt',time()],
                'effectEnd'=>['egt',time()],
                'store'=>['gt',0],
                'residue'=>['gt',0],
                'gift'=>['like','%'.$keys.'%']
            ];
            $row=db('product')->where($opt)->select();
            if($row){
                $arr=[];
                foreach ($row as $k=>$v){
                    $ins=$k+1;
                    array_push($arr,$ins.".". $v['gift'] ."\n 领取口令: " .$v['order']. "\n");
                }
                array_unshift($arr,'目前'.$keyWord.", 共计有".count($row)."款。\n");
                array_push($arr,'回复领取口令，根据提示完成验证即可获取礼包码哦！');
                return implode('',$arr);
            }else{
                $arr=[
                    "很遗憾！当前游戏礼包未发放中。\n",
                    "18183站内有海量游戏礼包。\n",
                    "不如换一个游戏再试试吧~\n",
                    "更多超值礼包，还请多多关注哦！"
                ];
                return implode('',$arr);
            }
        }elseif(preg_match('/^[a-zA-Z\d]{2,16}$/i',$keyWord)){
            $ss['order']=$keyWord;

            //基础条件控制
            $info=db('product')->where($ss)->find();
            if($info){
                //口令以及请求频次时间
                $token=$redis->get($openid);
                $frequency=(int)trim($info['frequency']) <= 10 ? 10 : (int)trim($info['frequency']);

                //发送频次
                if($token){
                    if(time()-$token<=$frequency){
                        $redis->del($openid);
                        return '当前领取过于频繁，请稍后再试!';
                    }else{
                        $redis->set($openid,time(),$frequency);
                    }
                }else{
                    $redis->set($openid,time(),$frequency);
                }

                if($info['isCheck']==1){
                    return $this->receiveGift($info,$ss,$openid,$base);
                }else{
                    $question=getRandom();
                    $redis->set($openid."@".$keyWord,trim($question['res']),(int)trim($base['checkExpire']));
                    $arr=[
                        "您还未验证哦！请回答下面问题，完成验证 \n",
                        "=====================\n",
                        $question['title']."？ \n",
                        "=====================\n",
                        "请回复“答案xx＋口令xxxx”，即可领取热门礼包码哦!\n",
                        "如答案为“12”、领取口令为“ABDE33”\n",
                        "则回复：答案12口令ABDE33"
                    ];
                    return implode('',$arr);
                }
            }else{
                $arr=[
                    "很遗憾，领取口令错误！\n",
                    "我们无法找到相关游戏的礼包。\n",
                    "离礼包只差一步啦!\n",
                    "点击查看礼包领取攻略，再来重新试试吧~"
                ];
                return implode('',$arr);
            }
        }elseif (mb_strpos($keyWord,'答案')!==false && mb_strpos($keyWord,'口令')!==false){
            $keys=trim(mb_substr($keyWord,mb_strpos($keyWord,'口令')+2));
            $ss['order']=$keys;

            //基础条件控制
            $info=db('product')->where($ss)->find();
            if($info){
                //口令以及请求频次时间
                $token=$redis->get($openid);
                $frequency=(int)trim($info['frequency']) <= 10 ? 10 : (int)trim($info['frequency']);
                //发送频次
                if($token){
                    if(time()-$token<=$frequency){
                        $redis->del($openid);
                        return '当前领取过于频繁，请稍后再试!';
                    }else{
                        $redis->set($openid,time(),$frequency);
                    }
                }else{
                    $redis->set($openid,time(),$frequency);
                }

                if($info['isCheck']==1){
                    $this->receiveGift($info,$ss,$openid,$base);
                }else{
                    $wow=$redis->get($openid."@".$keys);
                    if($wow!=false){
                        //游戏
                        $ans=trim(mb_substr($keyWord,mb_strpos($keyWord,'答案')+2,mb_strpos($keyWord,'口令')-2));
                        //答案验证
                        if($ans==trim($wow)){
                            $redis->del($openid."@".$keys);//删除验证
                            return $this->receiveGift($info,$ss,$openid,$base);
                        }else{
                            //答案错误
                            $arr=[
                                "很遗憾,答案错误，验证失败！\n",
                                "请重新输入领取口令，完成验证后领取礼包哦\n",
                                "18183站内有海量游戏礼包~\n",
                                "多多关注，薅你想要的羊毛~"
                            ];
                            return implode('',$arr);
                        }
                    }else{
                        $question=getRandom();
                        $redis->set($openid."@".$keys,trim($question['res']),(int)trim($base['checkExpire']));
                        $arr=[
                            "您还未验证哦！请回答下面问题，完成验证 \n",
                            "=====================\n",
                            $question['title']."？ \n",
                            "=====================\n",
                            "请回复“答案xx＋口令xxxx”，即可领取热门礼包码哦!\n",
                            "如答案为“12”、领取口令为“ABDE33”\n",
                            "则回复：答案12口令ABDE33"
                        ];
                        return implode('',$arr);
                    }
                }
            }else{
                $arr=[
                    "很遗憾，领取口令错误！\n",
                    "我们无法找到相关游戏的礼包。\n",
                    "离礼包只差一步啦!\n",
                    "点击查看礼包领取攻略，再来重新试试吧~"
                ];
                return implode('',$arr);
            }
        } else{
            //默认
            return implode('',$default);
        }
    }


    //领取
    public function receiveGift($info,$ss,$openid,$base){
        try{
            $product=db('product');
            $secret=db('secret');
            if($info['show']==2){
                if($info['effectStart']>time()){
                    $arr=[
                        "很遗憾！该游戏礼包当前未开始发放。\n",
                        "18183站内有海量游戏礼包。\n",
                        "不如换一个游戏再试试吧~\n",
                        "更多超值礼包，还请多多关注哦！"
                    ];
                    return implode('',$arr);
                }elseif($info['effectEnd']<time()){
                    $arr=[
                        "很遗憾！该游戏礼包当前已结束发放。\n",
                        "18183站内有海量游戏礼包。\n",
                        "不如换一个游戏再试试吧~\n",
                        "更多超值礼包，还请多多关注哦！"
                    ];
                    return implode('',$arr);
                } elseif($info['residue']<=0 || $info['store']<=0){
                    $arr=[
                        "很遗憾！该游戏礼包码当前暂无库存。\n",
                        "18183站内有海量游戏礼包。\n",
                        "不如换一个游戏再试试吧~\n",
                        "更多超值礼包，还请多多关注哦！"
                    ];
                    return implode('',$arr);
                }else {
                    $redis=new redis();
                    $count=$redis->lLen("receiveSecret");
                    $length=(int)$base['deal']>$count ? $count : (int)$base['deal'];
                    $range=$redis->lRange('receiveSecret',0,$length);
                    $co=1;$times='';

                    if($count>0){
                        foreach ($range as $k=>$v){
                            $tp=explode('@',$v);
                            //3超时踢出
                            if($tp[0]==$openid){
                                $co=2;
                                $times=$tp[1];
                                if(time()-$tp[1]>(int)trim($base['outTime'])){
                                    $redis->lRem("receiveSecret",$v,1);
                                    return '当前请求已超时，请稍后再输入领取';
                                }
                            }else{
                                if(time()-$tp[1]>(int)trim($base['outTime'])){
                                    $redis->lRem("receiveSecret",$v,1);
                                }
                            }
                        };

                        if($co==1){
                            $queue=(int)$base['queue']+(int)$base['deal'];
                            if($count>$queue){
                                return '当前领取人数较多，请稍后再输入领取';
                            }else{
                                $times=time();
                                if($count<=(int)$base['deal']){
                                    $redis->push(2, "receiveSecret", $openid.'@'.$times);
                                }else{
                                    $redis->push(2, "receiveSecret", $openid.'@'.$times);
                                    return '当前进入排队领取中，请稍后再输入领取';
                                }
                            }
                        }
                    }else{
                        $times=time();
                        $redis->push(2, "receiveSecret", $openid.'@'.$times);
                    }

                    //礼包码
                    $opts = ['pid' => $info['id'],'receive'=>2];
                    $op=['pid' => $info['id'], 'receive'=>1];

                    $ip=getClientIP();
                    //多人一码
                    if($info['sort']==2){
                        $sop=$secret->where($op)->find();
                        if($sop){
                            $receive = db('record')->where($opts)->select();

                            $next=2;$val='';$ipCount=0;
                            foreach ($receive as $k=>$v){
                                if($v['openid']==$openid) {
                                    $opts['openid'] = $openid;
                                    $val = $secret->where($opts)->value('secret');
                                    $next=1;
                                }else{
                                    if ($v['ip'] == $ip) {
                                        $ipCount++;
                                        if($ipCount>(int)$base['ip']) {
                                            $arr = [
                                                "系统检测该ip频段不正常,请稍后再试！ \n",
                                                "多次操作后将会判定为违规哦 \n",
                                            ];
                                            return implode('', $arr);
                                        }
                                    }
                                }
                            }

                            //是否已领取
                            if($next==1){
                                $redis->lRem("receiveSecret",$openid.'@'.$times,1);
                                $arr=[
                                    "您当前已领取过该游戏礼包哦！\n",
                                    "游戏礼包码为: \n",
                                    $val
                                ];
                                return implode('',$arr);
                            }else{
                                $send=[
                                    'ip'=>$ip,
                                    'openid'=>$openid,
                                    'receiveTime'=>time(),
                                    'sid'=>$sop['id'],
                                    'receive'=>2,
                                    'pid'=>$info['id']
                                ];
                                $lp=db('record')->insert($send);
                                if($lp){
                                    $redis->lRem("receiveSecret",$openid.'@'.$times,1);
                                    return $this->successTell($info,$sop['secret']);
                                }else{
                                    $redis->lRem("receiveSecret", $openid.'@'.$times, 1);
                                    $arr=[
                                        "很遗憾！该游戏礼包码领取失败。\n",
                                        "18183站内有海量游戏礼包。\n",
                                        "请稍后再尝试,获取礼包码！"
                                    ];
                                    return implode('',$arr);
                                }
                            }
                        }else{
                            $redis->lRem("receiveSecret",$openid.'@'.$times,1);
                            $arr=[
                                "很遗憾！该游戏礼包码当前已发放完毕。\n",
                                "18183站内有海量游戏礼包。\n",
                                "请重新输入其他游戏,获取礼包码！"
                            ];
                            return implode('',$arr);
                        }
                    }else{
                        //一人一码
                        if($info['sort']==1){
                            //是否已领取
                            $receive = $secret->where($opts)->select();
                            $ipCount=0;
                            foreach ($receive as $k=>$v){
                                if($v['openid']==$openid) {
                                    $opts['openid'] = $openid;
                                    $val = $secret->where($opts)->value('secret');
                                    $redis->lRem("receiveSecret",$openid.'@'.$times,1);
                                    $arr=[
                                        "您当前已领取过该游戏礼包哦！\n",
                                        "游戏礼包码为: \n",
                                        $val
                                    ];
                                    return implode('',$arr);
                                }else{
                                    //ip 限定
                                    if ($v['ip'] == $ip) {
                                        $ipCount++;
                                        if($ipCount>(int)$base['ip']){
                                            $arr=[
                                                "系统检测该ip频段不正常,请稍后再试！ \n",
                                                "多次操作后将会判定为违规哦 \n",
                                            ];
                                            return implode('',$arr);
                                        }
                                    }
                                }
                            }
                        }

                        $top = $secret->where($op)->field('id,secret,version')->select();
                        if ($top) {
                            //开始事务
                            Db::startTrans();
                            try{
                                //先减掉库存
                                $product->where($ss)->setDec('residue');
                                $ins = mt_rand(0, count($top) - 1); //随机
                                $set=$top[$ins];

                                $ups['id']=$set['id'];
                                $upVer=$secret->where($ups)->value('version');
                                if($set['version']==$upVer){
                                    //乐观锁版本提交
                                    $send=[
                                        'ip'=>$ip,
                                        'openid'=>$openid,
                                        'receive'=>2,
                                        'version'=>$set['version']+1,
                                        'receiveTime'=>time()
                                    ];
                                    $secret->where($ups)->update($send);
                                    Db::commit();
                                    $redis->lRem("receiveSecret",$openid.'@'.$times,1);
                                    return $this->successTell($info,$set['secret']);
                                }else{
                                    Db::rollback();
                                    $redis->lRem("receiveSecret",$openid.'@'.$times,1);
                                    return '当前领取人数较多，请稍后再输入领取游戏码';
                                }
                            }catch (\Exception $e) {
                                // 回滚事务
                                Db::rollback();
                                $redis->lRem("receiveSecret", $openid.'@'.$times, 1);
                                $arr=[
                                    "很遗憾！该游戏礼包码当前领取失败。\n",
                                    "18183站内有海量游戏礼包。\n",
                                    "请稍后再尝试,获取礼包码！"
                                ];
                                return implode('',$arr);
                            }
                        }else{
                            $redis->lRem("receiveSecret",$openid.'@'.$times,1);
                            $arr=[
                                "很遗憾！该游戏礼包码当前已发放完毕。\n",
                                "18183站内有海量游戏礼包。\n",
                                "不如换一个游戏再试试吧~\n",
                                "更多超值礼包，还请多多关注哦！"
                            ];
                            return implode('',$arr);
                        }
                    }
                }
            }else{
                $arr=[
                    "很遗憾！该游戏礼包当前已下架。\n",
                    "18183站内有海量游戏礼包。\n",
                    "不如换一个游戏再试试吧~\n",
                    "更多超值礼包，还请多多关注哦！"
                ];
                return implode('',$arr);
            }
        }catch (\Exception $e){
            return trim($e->getMessage());
        }
    }

    //成功领取
    public function successTell($info,$secret){
        $arr=[
            "恭喜您! 成功领取《".trim($info['gift'])."》!\n",
            "=====================\n",
            "账号卡密: \n",
            $secret. "\n",
            "礼包奖励: \n",
            $info['content']."\n",
        ];
        if(!$info['info'] && !$info['extra']){
            array_push($arr,"使用说明: \n");
            array_push($arr,"游戏内右上方-福利-兑换码激活\n");
            array_push($arr, "=====================\n");
            array_push($arr,"请尽快去游戏中兑换 , 祝您使用愉快！");
        }else{
            array_push($arr,"使用说明: \n");
            if($info['info']){
                array_push($arr,$info['info']."\n");
            }
            if($info['extra']){
                array_push($arr,$info['extra']."\n");
            }
            array_push($arr,"游戏内右上方-福利-兑换码激活\n");
            array_push($arr, "=====================\n");
            array_push($arr,"请尽快去游戏中兑换 , 祝您使用愉快！");
        }
        return implode('',$arr);
    }

    /*
     * 回复文本消息
     */
    private function transmitText($object, $content) {
        $textTpl = "<xml>
                    <ToUserName><![CDATA[%s]]></ToUserName>
                    <FromUserName><![CDATA[%s]]></FromUserName>
                    <CreateTime>%s</CreateTime>
                    <MsgType><![CDATA[text]]></MsgType>
                    <Content><![CDATA[%s]]></Content>
                    </xml>";
        $result = sprintf($textTpl, $object->FromUserName, $object->ToUserName, time(), $content);
        return $result;
    }


    /*
     * 文本推送
     */
    private function textPush($Content, $postObj) {
        $str = "<xml>
                <ToUserName><![CDATA[%s]]></ToUserName>
                <FromUserName><![CDATA[%s]]></FromUserName>
                <CreateTime>%s</CreateTime>
                <MsgType><![CDATA[%s]]></MsgType>
                <Content><![CDATA[%s]]></Content>
                </xml>";
        $ToUserName = $postObj->FromUserName; //发送方帐号（一个OpenID）
        $FromUserName = $postObj->ToUserName; //开发者微信号
        $MsgType = 'text'; //消息类型
        $responseStr = sprintf($str, $ToUserName, $FromUserName, time(), $MsgType, $Content);
        echo $responseStr;
    }


    public function access_token() {
        $config=config('wxChat');
        //①定义接口地址
        $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$config['AppID']."&secret=".$config['AppSecret'];
        //②获取接口内容
        $result_data = $this->http($url);
        //③对获取的json数据包进行解码
        $row = json_decode($result_data, true);
        $redis=new redis();
        if(isset($row['errcode']) && $row['errcode']!=false){
            $redis->set('access_log',$row['errmsg'],1800);
            return false;
        }else{
            $redis=new redis();
            $redis->set('menu_access',$row['access_token'],$row['expires_in']);
            return $row['access_token'];
        }
    }


    public function create_menu() {
        //①获取access_token
        $redis=new redis();
        $token=$redis->get('menu_access');
        $access_token= $token!=false  ? $token : $this->access_token();
        //②定义菜单内容
        $menu=[
           'button'=>[
               [
                   'name'=>'热门礼包',
                   'sub_button'=>[
                       [
                           'type' => 'view',
                           'name' => '近期上架',
                           'url' => 'https://mp.weixin.qq.com/mp/appmsgalbum?__biz=Mzg4MzgxNTQ3Nw==&action=getalbum&album_id=2457022262223503361#wechat_redirect',
                       ],
                       [
                           'type' => 'view',
                           'name' => '领取攻略',
                           'url' => 'https://mp.weixin.qq.com/s?__biz=Mzg4MzgxNTQ3Nw==&mid=2247496816&idx=1&sn=ecaf4082da6aac4a9d65b091e4dc0519&chksm=cf43112af834983c81d6319f8518b0f459949d8378b8a63ab63bb89ff79b77bc006352664fb7&token=1016495193&lang=zh_CN#rd',
                       ]
                    ]
               ],
               [
                   'name'=>'聊游戏',
                   'sub_button'=>[
                       [
                           'type' => 'view',
                           'name' => '每日游闻',
                           'url' => 'https://mp.weixin.qq.com/mp/appmsgalbum?__biz=Mzg4MzgxNTQ3Nw==&action=getalbum&album_id=2457445771550588929#wechat_redirect',
                       ],
                       [
                           'type' => 'view',
                           'name' => '侃侃游戏',
                           'url' => 'https://mp.weixin.qq.com/mp/appmsgalbum?__biz=Mzg4MzgxNTQ3Nw==&action=getalbum&album_id=2457349552505552896#wechat_redirect',
                       ],
                       [
                           'type' => 'view',
                           'name' => '新游评测',
                           'url' => 'https://mp.weixin.qq.com/mp/appmsgalbum?__biz=Mzg4MzgxNTQ3Nw==&action=getalbum&album_id=2461234283366252545#wechat_redirect'
                       ]
                   ]
               ],
               [
                   'name'=>'在线游戏',
                   'sub_button'=>[
                       [
                           'type' => 'view',
                           'name' => '异界深渊：觉醒',
                           'url' => 'http://www.shandw.com/mi/game/2055894733.html?channel=19922'
                       ],
                       [
                           'type' => 'view',
                           'name' => '九州仙剑传',
                           'url' => 'http://www.shandw.com/mi/game/1955231439.html?channel=19922'
                       ],
                       [
                           'type' => 'view',
                           'name' => '天剑奇缘',
                           'url' => 'http://www.shandw.com/mi/game/2072605901.html?channel=19922',
                       ],
                       [
                           'type' => 'view',
                           'name' => '决战沙城',
                           'url' => 'http://www.shandw.com/mi/game/1247433539.html?channel=19922'
                       ],
                       [
                           'type' => 'view',
                           'name' => '斗罗大陆',
                           'url' => 'http://www.shandw.com/mi/game/2038737096.html?channel=19922',
                       ]
                   ]
               ]
           ]
        ];
        //③开始调用自定义菜单接口
        $url = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$access_token;
        //④获取接口内容并生成菜单
        $result = $this->http($url, $this->json_encode($menu));
        return $result;
    }


    /**
     * 微信api不支持中文转义的json结构
     * @param array $arr
     */
    public static function json_encode($arr) {
        $parts = array();
        $is_list = false;
        //Find out if the given array is a numerical array
        $keys = array_keys($arr);
        $max_length = count($arr) - 1;
        if (($keys[0] === 0) && ($keys[$max_length] === $max_length)) {
            //See if the first key is 0 and last key is length - 1
            $is_list = true;
            for ($i = 0; $i < count($keys); $i++) {
                //See if each key correspondes to its position
                if ($i != $keys[$i]) {
                    //A key fails at position check.
                    $is_list = false; //It is an associative array.
                    break;
                }
            }
        }
        foreach ($arr as $key => $value) {
            if (is_array($value)) {
                //Custom handling for arrays
                if ($is_list) {
                    $parts[] = self::json_encode($value);
                }
                /* :RECURSION: */ else {
                    $parts[] = '"' . $key . '":' . self::json_encode($value);
                }
                /* :RECURSION: */
            } else {
                $str = '';
                if (!$is_list) {
                    $str = '"' . $key . '":';
                }

                //Custom handling for multiple data types
                if (is_numeric($value) && $value < 2000000000) {
                    $str .= $value;
                }
                //Numbers
                elseif ($value === false) {
                    $str .= 'false';
                }
                //The booleans
                elseif ($value === true) {
                    $str .= 'true';
                } else {
                    $str .= '"' . addslashes($value) . '"';
                }
                //All other things
                // :TODO: Is there any more datatype we should be in the lookout for? (Object?)
                $parts[] = $str;
            }
        }
        $json = implode(',', $parts);
        if ($is_list) {
            return '[' . $json . ']';
        }
        //Return numerical JSON
        return '{' . $json . '}'; //Return associative JSON
    }

    /*
     * curl工具
     */
    public function http($url, $data = null) {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        if (!empty($data)) {
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
}