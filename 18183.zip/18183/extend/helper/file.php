<?php
namespace helper;


class file{
//opendir ( $path ) 打开路径目录，返回资源
//readdir ( $handle ) 读取当前打开目录下一个文件，同时指针向前移动一位，返回字符串 （文件/目录名）
    public $data=[];
    //查看目录下文件信息
    public function dir($dir){
        $data=[];
        $index=0;
        if (is_dir($dir)){
            if ($dh = opendir($dir)){
                while (($file = readdir($dh))!= false){
                    //文件名的全路径 包含文件名
                    $filePath = $dir.'/'.$file;
                    //获取文件修改时间
                    if(is_file($filePath)){
                        $index++;
                        $size=filesize($filePath);
                        if($size >= pow(2, 40)){
                            $show=round($size/pow(2, 40), 2).'TB';
                        } else if($size >= pow(2, 30)){
                            $show=round($size/pow(2, 30), 2).'GB';
                        } else if($size >= pow(2, 20)){
                            $show=round($size/pow(2, 20), 2).'MB';
                        } else if($size >= pow(2, 10)){
                            $show=round($size/pow(2, 10), 2).'KB';
                        }else{
                            $show=round($size, 2).'B';
                        }

                        $amt = filectime($filePath);  //添加时间
                        $emt = filemtime($filePath); //修改时间
                        $type= filetype($filePath);
                        array_push($data,[
                            'path'=>$file,
                            'realPath'=>$filePath,
                            'etime'=>date("Y-m-d H:i",$emt),
                            'atime'=>date("Y-m-d H:i",$amt),
                            'size'=>$show,
                            'type'=>$type,
                            'id'=>$index
                        ]);
                    }
                }
                closedir($dh);
            }
        }
       return $data;
    }

    //dede拉模板选择
    public function dirMenu($dir){
        $data=[];
        $index=0;
        if (is_dir($dir)){
            if ($dh = opendir($dir)){
                while (($file = readdir($dh))!= false){
                    //文件名的全路径 包含文件名
                    $filePath = $dir.'/'.$file;
                    //获取文件修改时间
                    if(is_file($filePath)){
                        $index++;
                        array_push($data,[
                            'path'=>$file,
                            'id'=>$index
                        ]);
                    }
                }
                closedir($dh);
            }
        }
        return $data;
    }


    //tp下拉模板选择
    //type: 1不可选择  2为可选择
    public function dirMenus($dir,$ro='底层模板-(layout)',$index=0,$type=1,$sort=1){
        if (is_dir($dir)){
            if ($dh = opendir($dir)){
                while (($file = readdir($dh))!= false){
                    //文件名的全路径 包含文件名
                    $filePath = $dir.'/'.$file;
                    //获取文件修改时间
                    if(is_file($filePath)){
                        $index++;
                        $size=filesize($filePath);
                        if($size >= pow(2, 40)){
                            $show=round($size/pow(2, 40), 2).'TB';
                        } else if($size >= pow(2, 30)){
                            $show=round($size/pow(2, 30), 2).'GB';
                        } else if($size >= pow(2, 20)){
                            $show=round($size/pow(2, 20), 2).'MB';
                        } else if($size >= pow(2, 10)){
                            $show=round($size/pow(2, 10), 2).'KB';
                        }else{
                            $show=round($size, 2).'B';
                        }

                        $amt = filectime($filePath);  //添加时间
                        $emt = filemtime($filePath); //修改时间
                        array_push($this->data,[
                            'path'=>$file,
                            'id'=>$index,
                            'extra'=>$ro,
                            'isChoose'=>$type,
                            'realPath'=>$filePath,
                            'etime'=>date("Y-m-d H:i",$emt),
                            'atime'=>date("Y-m-d H:i",$amt),
                            'size'=>$show,
                            'sort'=>$sort
                        ]);
                    }

                    if(is_dir($filePath)){
                        switch ($file){
                            case 'Menu':
                                $this->dirMenus($filePath,'模板文件-(Template)',10,3,2);
                                break;
                            case 'Public':
                                $this->dirMenus($filePath,'公共文件-(Public)',200,1,3);
                                break;
                            case 'Widget':
                                $this->dirMenus($filePath,'动态文件-(Widget)',300,1,4);
                                break;
                        }
                    }
                }
                closedir($dh);
            }
        }
        return $this->data;
    }

    //目录操作
    public function dirAction($dir,$type,$rename=''){
            switch ($type){
                case 1:
                    if(!is_dir($dir)){
                        //新增
                        mkdir($dir, 0777, true);
                    }
                    break;
                case 2:
                    if(is_dir($dir)) {
                        //删除空目录
                        rmdir($dir);
                    }else {
                        errorReturn(1050,'目录不存在');
                    }
                    break;
                //删除非空目录
                case 3:
                    if(file_exists($dir)){
                        if(false != ($handle = opendir($dir))){
                            while(false != ($name = readdir($handle))){
                                if($name == '.' || $name == '..')
                                    continue;
                                $filename = $dir.'/'.$name;
                                if(is_dir($filename))
                                    $this->dirAction($filename,3);
                                if(is_file($filename))
                                    @unlink($filename);
                            }
                            closedir($handle);
                            rmdir($dir);
                        } else{
                            return false;
                        }
                    }
                    break;
                case 4:
                    if(is_dir($dir)) {
                        rename($dir, $rename);
                    }else{
                        errorReturn(1050,'目录不存在');
                    }
                    break;
            }
    }

    //文件操作
    public function fileAction($path,$type,$content=''){
            switch ($type){
                case 1:
                    $handle=fopen($path,'w+');
                    // ‘w+’ 读写方式打开，将文件指针指向文件头并将文件大小截为零。如果文件不存在则尝试创建之。
                    $cos=fputs($handle,$content);  //fwrite亦可,返回字符数
                    fclose($handle);
                    return $cos;
                    break;
                case 2:
                    if(file_exists($path)) {
                        return unlink($path);
                    }else{
                        errorReturn(1050,'文件不存在');
                    }

                    break;
                case 3:
                    if(file_exists($path)) {
                        //文件读取
                        return file_get_contents($path); //将整个文件读入一个字符串
                    }else{
                        errorReturn(1050,'文件不存在');
                    }
                    // file($path);   //把文件读入一个数组中
                    break;
                //修改文件
                case 4:
                    if(file_exists($path)) {
                        return rename($path, $content);
                    }else{
                        errorReturn(1050,'文件不存在');
                    }
                    break;
            }
    }
}