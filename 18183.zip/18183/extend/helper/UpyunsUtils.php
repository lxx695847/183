<?php
namespace helper;
/**
 * 功能描述： 又拍云-云存储-上传图片类
 *
 * @author ZHL
 * @createDate 2020/09/14
 * @version V1.0.1
 */

class UpyunsUtils{
    // 又拍云帐号配置【配置成自己的】
    private $serviceUrl = 'http://v0.api.upyun.com/'; // 接口服务地址
    private $serviceName = 'guangzi-video'; // 云存储服务名
    private $operatorName = 'guangzi';   // 操作员帐号
    private $operatorPwd = 'vbZoqxsKp39qTR2EyXVzLbrwhvca4pme'; // 操作员密码
    public $upimgUrl = 'files.guangziyouyun.com'; // 文件加速域名
    // 上传相关配置
    private $fileMaxSize = 5242880; // 5Mb(1024*1024*5)，服务器限流减轻压力
    private $fileType = 'jpg|jpeg|png|gif|bmp|webp'; // 基本常用图片格式
    private $filePath = '/video/';
    // 其他属性
    private $fileNewPath;
    private $fileNewName;
    private $fileSuffix;
    private $fileSize;
    private $submitType;

    public function __construct($submitType = 1){
        // 提交操作类型(文件保存到/文件删除)：1又拍云，2本服务器，3又拍云+本服务器
        $this->submitType = intval($submitType) ? intval($submitType) : 1;
    }

    /**
     * Notes: base64图片上传
     * User: ZHL
     * Date: 2020/9/14
     */
    public function base64Upload($fileData, $filePath='', $fileSize='', $fileType=''){
        $restRes = $this->resetData($filePath, $fileSize, $fileType);
        if($restRes){
            return $restRes;
        }
        if(!$fileData){
            return $this->errorArr(40000);
        }

        // 正则匹配填充搜索结果
        if(!preg_match('/^(data:\s*image\/(\w+);base64,)/', $fileData, $res)){
            return $this->errorArr(40000);
        }
        $this->fileSuffix = $res[2]; // 文件类型
        // 文件类型判断
        if(!in_array($this->fileSuffix, explode('|',$this->fileType))){
            return $this->errorArr(40001);
        }
        // 文件大小
        $baseImg = str_replace($res[1], '', $fileData);
        $baseImg =str_replace('=','',$baseImg);
        $imgLen = strlen($baseImg);
        $this->fileSize = intval($imgLen - ($imgLen/8)*2);
        if($this->fileSize > $this->fileMaxSize){
            return $this->errorArr(40002);
        }

        // 拼接文件全路径
        $this->fileNewName = date('YmdHis').$this->msec();
        $this->fileNewPath = $this->filePath.$this->fileNewName.'.'.$this->fileSuffix;
        $fileNewPath = '.'.$this->fileNewPath;
        if(!file_put_contents($fileNewPath, base64_decode(str_replace($res[1], '', $fileData)))){
            return $this->errorArr(30000);
        }
        $fileInfo = $this->getFileInfo($fileNewPath);
        $result = $this->errorArr(10000);
        $result['data'] = $fileInfo;
        $result['data']['name'] = $this->fileNewName.'.'.$this->fileSuffix;
        $result['data']['path'] = $this->fileNewPath;
        $result['data']['type'] = $this->fileSuffix;
        if($this->submitType == 1 || $this->submitType == 3){ // 上传至 又拍云
            $upRes = $this->upyunUpload(realpath($fileNewPath), $this->fileNewPath);
            $result['data']['upimg'] = '';
            if($upRes['code'] == 10000){
                $result['data']['upimg'] = $upRes['upimg'];
                $result['data']['upcdn'] = $upRes['upcdn'];
            }
            if($this->submitType == 1 && $upRes['upimg']){
                @unlink($fileNewPath);
            }
        }
        return $result;
    }

    /**
     * Notes:二进制数据流上传
     * User: ZHL
     * Date: 2020/9/14
     */
    public function blobUpload($fileData, $filePath='', $fileSize='', $fileType=''){
        if(!isset($_FILES)){
            return $this->errorArr(40000);
        }
        $restRes = $this->resetData($filePath, $fileSize, $fileType);
        if($restRes){
            return $restRes;
        }
        if(!$fileData){
            return $this->errorArr(40000);
        }
        $files = $_FILES[$fileData];
        $fileName = $files['name'];
        $fileSize = $files['size'];
        $fileTmp = $files['tmp_name'];

        if($fileSize > $this->fileMaxSize){
            return $this->errorArr(40002);
        }
        $suf = @pathinfo($fileName, PATHINFO_EXTENSION); // 文件后缀
        $suffix = $suf ? strtolower($suf) : ''; // 转小写
        if(!$suffix){
            return $this->errorArr(40001);
        }
        $this->fileSuffix = $suffix;
        if(!in_array($suffix, explode('|',$this->fileType))){
            return $this->errorArr(40001);
        }
        $this->fileNewName = date('YmdHis').$this->msec();
        $this->fileNewPath = $this->filePath.$this->fileNewName.'.'.$this->fileSuffix;
        $fileNewPath = '.'.$this->fileNewPath;
        // 将上传的文件临时数据移动到新位置

        if(!move_uploaded_file($fileTmp, $fileNewPath)){
            return $this->errorArr(30000);
        }

        $fileInfo = $this->getFileInfo($fileNewPath);
        $result = $this->errorArr(10000);
        $result['data'] = $fileInfo;
        $result['data']['name'] = $this->fileNewName.'.'.$this->fileSuffix;
        $result['data']['path'] = $this->fileNewPath;
        $result['data']['type'] = $this->fileSuffix;
        if($this->submitType == 1 || $this->submitType == 3){ // 上传至 又拍云
            $upRes = $this->upyunUpload(realpath($fileNewPath), $this->fileNewPath);
            $result['data']['upimg'] = '';
            if($upRes['code'] == 10000){
                $result['data']['upimg'] = $upRes['upimg'];
                $result['data']['upcdn'] = $upRes['upcdn'];
            }
            if($this->submitType == 1 && $upRes['upimg']){
                @unlink($fileNewPath);
            }
        }
        return $result;
    }

    /**
     * Notes: 本地路径上传（相对路径/绝对路径）
     * User: ZHL
     * Date: 2020/9/14
     */
    public function localUpload($filePath){
        $files = explode('/',$filePath);
        $fileName = end($files);
        $fileNewPath = '.'.$this->filePath.$fileName;
        $res = @copy($filePath,$fileNewPath);
        if(!$res){
            return $this->errorArr(30000);
        }
        $sub = explode('.',$fileName);
        $result = $this->errorArr(10000);
        $fileInfo = $this->getFileInfo($filePath);
        $result['data'] = $fileInfo;
        $result['data']['name'] = $fileName;
        $result['data']['path'] = $this->filePath.$fileName;
        $result['data']['type'] = end($sub);
        if($this->submitType == 1 || $this->submitType == 3){ // 上传至 又拍云
            $upyunFilePath = @realpath($filePath);
            $upRes = $this->upyunUpload($upyunFilePath,$this->filePath.$fileName);
            $result['data']['upimg'] = '';
            if($upRes['code'] == 10000){
                $result['data']['upimg'] = $upRes['upimg'];
                $result['data']['upcdn'] = $upRes['upcdn'];
            }
            if($this->submitType == 1 && $upRes['upimg']){
                @unlink($fileNewPath);
            }
            return $result;
        }
        return $result;
    }

    /**
     * Notes:文件删除
     * User: ZHL
     * Date: 2020/9/14
     * @param $filePath (去掉域名的路径)
     * @return array
     */
    public function delFile($filePath){
        if(!$filePath){
            return $this->errorArr(40000);
        }
        if($this->submitType == 1 || $this->submitType == 3){
            if($this->submitType == 3) {
                @unlink($filePath);
            }
            $filePath = ltrim($filePath,'.');
            $upRes = $this->upyunDel($filePath);
            if($upRes['code'] == 10000){
                return $this->errorArr(10000);
            }
        }
        return $this->errorArr(30000);
    }

    /**
     * Notes:上传至又拍云
     * User: ZHL
     * Date: 2020/9/14
     * @param $file （文件绝对路径）
     * @param string $filePath（文件夹目录）
     * @return array
     */
    public function upyunUpload($file, $filePath=''){
        $filePath = $filePath ? $filePath : $this->filePath.date('YmdHis').$this->msec().'.jpg';
        $filePath = ltrim($filePath,'.');
        $serverName = $this->serviceName;
        $userName = $this->operatorName;
        $userPwd = $this->operatorPwd;
        set_time_limit(0);
        $process = curl_init($this->serviceUrl.$serverName. $filePath);
        curl_setopt($process, CURLOPT_PUT, 1);
        curl_setopt($process, CURLOPT_USERPWD, $userName.':'.$userPwd);
        curl_setopt($process, CURLOPT_HEADER, false);
        curl_setopt($process, CURLOPT_TIMEOUT, 60);

        $imageData = fopen($file, 'r');
        fseek($imageData, 0, SEEK_END);
        $file_length = ftell($imageData);
        fseek($imageData, 0);
        curl_setopt($process, CURLOPT_INFILE, $imageData);
        curl_setopt($process, CURLOPT_INFILESIZE, $file_length);
        curl_setopt($process, CURLOPT_HTTPHEADER, array(
            'x-gmkerl-unsharp: true',
            'x-gmkerl-thumb:/format/png',
            'Mkdir:true',
        ));
        $ch = curl_exec($process);
        curl_close($process);
        fclose($imageData);
        if ($ch === true) {
            return array('code' => '10000', 'upimg' => $filePath, 'upcdn' => $this->upimgUrl);
        } else {
            return array('code' => '30000', 'msg' => $ch);
        }
    }

    /**
     * Notes: 又拍云-删除
     * User: ZHL
     * Date: 2020/9/14
     * @param $file 图片相对路径
     * @return array
     */
    public function upyunDel($file){
        $file = ltrim($file,'.');
        $serverName = $this->serviceName;
        $userName = $this->operatorName;
        $userPwd = $this->operatorPwd;
        set_time_limit(0);
        $curl_handle = curl_init ();
        // Set default options.
        curl_setopt($curl_handle, CURLOPT_URL, $this->serviceUrl.$serverName. $file);
        curl_setopt($curl_handle, CURLOPT_USERPWD, $userName.':'.$userPwd);
        curl_setopt($curl_handle, CURLOPT_FILETIME, true );
        curl_setopt($curl_handle, CURLOPT_FRESH_CONNECT, false);
        curl_setopt($curl_handle, CURLOPT_HEADER, false);
        curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl_handle, CURLOPT_TIMEOUT, 60);
        curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 120);
        curl_setopt($curl_handle, CURLOPT_NOSIGNAL, true);
        curl_setopt($curl_handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
        $ret = curl_exec ( $curl_handle );
        $httpCode = curl_getinfo($curl_handle,CURLINFO_HTTP_CODE);
        if($httpCode == 200) {
            return array('code' => '10000','msg' => 'Success');
        } else {
            return array('code' => '30000', 'msg' => $ret);
        }
    }

    /**
     * Notes: 参数配置重置
     * User: ZHL
     * Date: 2020/9/14
     */
    private function resetData($filePath, $fileSize, $fileType){
        if($filePath){
            $filePath = trim($filePath,'.');
            $filePath = trim($filePath,'/');
            $this->filePath = '/'.$filePath.'/';
        }
        $result = $this->createPath($this->filePath);
        if(!$result){
            return $this->errorArr(40003);
        }
        if(intval($fileSize) > 0){
            $this->filePath = intval($fileSize);
        }
        if($fileType){
            $this->fileType = strval($fileType);
        }
    }

    /**
     * Notes: 获取图片文件信息
     * User: ZHL
     * Date: 2020/9/14
     * @param $filePath
     * @return mixed
     */
    private function getFileInfo($filePath){
        $imageData = @getimagesize($filePath);
        $res['width'] = isset($imageData[0]) ? $imageData[0] : 0;
        $res['height'] = isset($imageData[1]) ? $imageData[1] : 0;
        $res['size'] = filesize($filePath);
        $res['sizetxt'] = sprintf('%.2f',$res['size']/1024).'kb';
        return $res;
    }

    /**
     * Notes:创建文件夹
     * User: ZHL
     * Date: 2020/9/14
     * @param $path
     * @return bool
     */
    private function createPath($path){
        $result = true;
        $pathBy = array_filter(explode('/',$path)); //数组去除空值
        $pathNo = '';
        $pathAll = '';
        foreach($pathBy as $v){
            if($v == '.'||$v == '..'){
                $pathNo = $pathNo.$v.'/';
            }else{
                $pathAll = $pathAll.$pathNo.$v.'/';
                if(!file_exists($pathAll)){
                    if(@!mkdir($pathAll)){
                        $result = false;
                    }
                }
                $pathNo = '';
            }
        }
        return $result;
    }

    /**
     * Notes:获取3位毫秒数
     * User: ZHL
     * Date: 2020/9/14
     * @return string
     */
    private function msec(){
        list($usec, $sec) = explode(" ", microtime());
        $msec = round($usec*1000);
        return sprintf("%03d", $msec);
    }

    /**
     * Notes:错误码
     * User: ZHL
     * Date: 2020/9/14
     * @return array
     */
    private function errorArr($code){
        $error = array(
            '10000'=>array('code'=>'10000','msg'=>'Success'),
            '20000'=>array('code'=>'20000','msg'=>'网络异常'),
            '30000'=>array('code'=>'30000','msg'=>'Fail'),
            '40000'=>array('code'=>'40000','msg'=>'文件信息错误'),
            '40001'=>array('code'=>'40001','msg'=>'文件类型不支持'),
            '40002'=>array('code'=>'40002','msg'=>'文件大小超出'.($this->fileMaxSize/(1024*1024)).'Mb'),
            '40003'=>array('code'=>'40003','msg'=>'文件目录不存在'),
            '50000'=>array('code'=>'50000','msg'=>'未知错误'),
        );
        return isset($error[$code]) ? $error[$code] : $error['50000'];
    }
}