const imgUrl=window.location.protocol+"//"+window.location.host+"/Uploads/";
const videoUrl=window.location.protocol+"//"+window.location.host+"/Uploads/";
function getUrl(key) {
// 获取参数
    var url = window.location.search;
// 正则筛选地址栏
    var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
// 匹配目标参数
    var result = url.substr(1).match(reg);
//返回参数值(解决中文乱码)
    return result ? decodeURIComponent(result[2]) : null;
}


var e=[];
function get_check(arr1,arr2){
    "use strict";
    for (var i = 0; i < arr1.length; i++) {
        if (arr2.indexOf(arr1[i])==-1) {
            e.push(arr1[i])
        }
    }
    if(e.length!=0){
        e=[];
        return false
    }else{
        return true;
    }
}

function count(obj){
    var objType = typeof obj;
    if(objType == "string"){
        return obj.length;
    }else if(objType == "object"){
        var objLen = 0;
        for(var i in obj){
            objLen++;
        }
        return objLen;
    }
    return false;
}


//获取当前的Y-M-D
function getDay() {
    var datetime = new Date();
    var Y = datetime.getFullYear();
    var m = datetime.getMonth() + 1;
    var d = datetime.getDate();
    return Y + '-' + parse(m) + '-' + parse(d);
}

function getDays() {
    var datetime = new Date();
    var m = datetime.getMonth() + 1;
    var d = datetime.getDate();
    return parse(m) + '-' + parse(d);
}

function getTime(time) {
    var date = "";  //用时
    var d = parseInt(time / (3600 * 24))
    var h = parseInt(time % 86400 / 3600);
    var m = parseInt(time % 3600 / 60);
    var s = parseInt(time % 60);
    d = d < 10 ? "0" + d : d;
    h = h < 10 ? "0" + h : h;
    m = m < 10 ? "0" + m : m;
    s = s < 10 ? "0" + s : s;
    if (d == 0) {
        if (h == 0) {
            if (m == 0) {
                if (s == 0) {
                    date = '';
                } else {
                    date += s + "秒";
                }
            } else {
                date += m + "分" + s + "秒";
            }
        } else {
            date += h + "时" + m + "分" + s + "秒";
        }
    } else {
        date += d + "天" + h + "时" + m + "分" + s + "秒";
    }
    return date;
}

function timeStamp(dates) {
    var times = new Date(dates);
    var need =Date.parse(times)/1000;
    return need;
}


function parse(m){return m<10?'0'+m:m }

//时间戳转换格式
function changeDate(time,type) {
    var date = new Date(parseInt(time));
    var Y = date.getFullYear();
    var m = date.getMonth()+1;
    var d = date.getDate();
    var h = date.getHours();
    var i = date.getMinutes();
    var send="";
    switch (type) {
        case 1:
            send=Y+'-'+parse(m)+'-'+parse(d)+' '+parse(h)+':'+parse(i);
            break;
        case 2:
            var s = date.getSeconds();
            send=Y+'-'+parse(m)+'-'+parse(d)+' '+parse(h)+':'+parse(i)+':'+parse(s);
            break;
        case 3:
            send=Y+'-'+parse(m)+'-'+parse(d);
            break;
    }
    return send;
}


function getBack() {
    pushHistory();
    window.addEventListener("popstate", function(e) {
        alert("我监听到了浏览器的返回按钮事件啦");//根据自己的需求实现自己的功能
    }, false);
    function pushHistory() {
        var state = {
            title: "title",
            url: "#"
        };
        window.history.pushState(state, "title", "#");
    }
}

function formatDuring(time) {
    var m = Math.floor(time / 1000 / 60 % 60);
    var s = Math.floor(time / 1000 % 60);
    var ms = Math.floor(time % 1000);
    return  parse(m)+":"+parse(s)+":"+parse(ms);
}

//浏览器检测
function isWeiXin(){
    var ua = window.navigator.userAgent.toLowerCase();
    //微信浏览器
    if(ua.match(/MicroMessenger/i) == 'micromessenger'){
        return true;
    }else{
        return false;
    }
}

function getHeight(name,scale) {
    return Math.round($(name).width()/scale);
}




