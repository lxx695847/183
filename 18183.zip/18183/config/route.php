<?php
use think\Route;
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
//接口模块
Route::rule([
    //登录
    'getCurrentUser'=>'@api/Cms/currentUser',
    'menuData'=>'@api/Cms/menuData',
    //权限相关
    'getUsers'=>'@api/Cms/getUsers',
    'getGroups'=>'@api/Cms/getGroups',
    'watch_auth'=>'@api/Cms/watch_auth',
    'edit_auth'=>'@api/Cms/edit_auth',
    'userRole'=>'@api/Cms/userRole',

    //测试数据
    'getUserInfo'=>'@api/Order/getUserInfo',
    'getPartMent'=>'@api/Order/getPartMent',
    'PartMentInfo'=>'@api/Order/PartMentInfo',
    'giftList'=>'@api/Order/giftList',
    'giftDelete'=>'@api/Order/giftDelete',
    'giftAdd'=>'@api/Order/giftAdd',
    'giftEdit'=>'@api/Order/giftEdit',
    'cardDetail'=>'@api/Order/cardDetail',
    'cardDelete'=>'@api/Order/cardDelete',
    'setConfig'=>'@api/Order/setConfig',

    //微信公众号
    'getCheck'=>'@api/Order/getCheck',
    'getOpen'=>'@api/Order/getOpen',

    'getPhones'=>'@api/Login/getPhones',
    'getPhone'=>'@api/Login/getPhone',
    'getAccess'=>'@api/Login/getAccess',
    'getCode'=>'@api/Login/getCode'
]);



