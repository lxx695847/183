<?php
//define("scp","http://".$_SERVER['HTTP_HOST']."/static/");
//define("svp","http://".$_SERVER['HTTP_HOST']."/Uploads/");   //链接前缀
define('mainUrl',$_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME']);
define("vip",ROOT_PATH . 'public' . DS . 'Uploads/');     //根目录
define('aesKey',"SDF561werSFDBHJIoinju165iuheifAS");
use helper\Rsas;
use afs\Request\V20180112 as Afs;

// 应用公共文件
function errorReturn($code,$info=""){
    header('Content-Type:application/json; charset=utf-8');
    $data['code']=$code;
    $data['status']=1;

    if($code==400){
        $data['info'] ="参数缺失";
    }elseif ($code==401){
        $data['info'] = "未授权认证或参数错误";
    }elseif($code==402){
        $data['info']= "内容已存在或重复提交";
    }elseif($code==403){
        $data['info']= "请求的方式错误";
    }elseif ($code==404){
        $data['info']= "请求的资源不存在";
    }elseif ($code==405){
        $data['info']= "操作失败或暂无更新";
    }elseif ($code==406){
        $data['info']= "数据已更改";
    }else{
        $data['info']=$info;
    }

    if($info){
        $data['info']=$info;
    }
    echo json_encode($data);
    exit;
}


//阿里云滑动验证码
function getAsf($sessionId,$Token,$sig){
    include '../vendor/aliyun-php-sdk-core/Config.php';
//YOUR ACCESS_KEY、YOUR ACCESS_SECRET请替换成您的阿里云accesskey id和secret
    $iClientProfile = DefaultProfile::getProfile("cn-hangzhou", config('afs.AccessKey'), config('afs.AccessSecret'));
    $client = new DefaultAcsClient($iClientProfile);
    DefaultProfile::addEndpoint("cn-hangzhou", "cn-hangzhou", "afs", "afs.aliyuncs.com");

    $request = new Afs\AuthenticateSigRequest();
    $request->setSessionId($sessionId);// 会话ID。必填参数，从前端获取，不可更改。
    $request->setToken($Token);// 请求唯一表示。必填参数，从前端获取，不可更改。
    $request->setSig($sig);// 签名串。必填参数，从前端获取，不可更改。
    $request->setScene(config('afs.scene'));// 场景标识。必填参数，从前端获取，不可更改。
    $request->setAppKey(config('afs.appKey'));// 应用类型标识。必填参数，后端填写。
    $request->setRemoteIp(getClientIP());// 客户端IP。必填参数，后端填写。
    $response = $client->getAcsResponse($request);// 返回code 100表示验签通过，900表示验签失败
    $row=json_decode(json_encode($response),true);
    switch ($row['Code']){
        case 100:
            successReturn($row['Code'],$row['Msg']);
            break;
        case 900:
            errorReturn($row['Code'],$row['Msg']);
            break;
    }
}

function successReturn($code, $info="",$result = array()){
    header('Content-Type:application/json; charset=utf-8');
    $data=[
        'code'=>$code,
        'data'=>$result
    ];
    switch ($code){
        case 200:
            $data['info']="请求成功";
            break;
        case 201:
            $data['info']="创建成功";
            break;
        case 202:
            $data['info']="更新成功";
            break;
        case 203:
            $data['info']="删除或取消成功";
            break;
        case 204:
            $data['info']="暂无内容";
            break;
        case 205:
            $data['info']="操作成功";
            break;
        case 206:
            $data['info']=$info;
    }
    $data['status']=2;
    echo json_encode($data);
    exit;
}

//数据操作(增、删、改)的简单验证
function result_check($result,$s_code,$data=[],$e_code,$info=""){
    if($result!==false){
        successReturn($s_code,"",$data);
    }else{
        errorReturn($e_code,$info);
    }
}

//数据查询简单验证
function result_show($result){
    if($result){
        successReturn(200,"",$result);
    }else{
        successReturn(204);
    }
}

//常见操作验证
function check($data,$type,$send=array()){
    if ($data!==false) {
        switch ($type){
            //新增
            case 1:
                successReturn(201,'',$send);
                break;
            //更新
            case 2:
                successReturn(202,'',$send);
                break;
            //删除
            case 3:
                successReturn(203);
                break;
        }
    } else {
        errorReturn(405);
    }
}


//获取最近7天的时间日期
function get_week(){
    //获取当前周几
    $date = [];
    $date[0] = date('Y-m-d', time());
    for ($i=1; $i<7; $i++){
        $date[$i] = date('Y-m-d' ,strtotime( '-' . $i .' days', time()));
    }
    $row=array_reverse($date);
    return $row;
}

//手机号验证
function checkPhone($phone_number){
    $g ="/^1((34[0-8]\d{7})|((3[0-3|5-9])|(4[5-7|9])|(5[0-3|5-9])|(66)|(7[2-3|5-8])|(8[0-9])|(9[1|8|9]))\d{8})$/";
    if(preg_match($g,$phone_number)){
        return true;
    }
    return false;
}

//layui 表格渲染格式
function layui_table($data){
    $list=[
        'code'=>0,
        'msg'=>"111",
        'count'=>$data['count'],
        'data'=>$data['list']
    ];
//    ob_end_clean();
    echo json_encode($list);
    exit;
}

/**
 * 递归菜单
 * @param  $array
 * @param  $pid
 * @return array
 */
function get_menu($array,$pid=0)
{
    $column = [];
    foreach($array as $key => $vo) {
        if ($vo['pid'] == $pid) {
            $vo['sub'] = get_menu($array, $vo['id']);
            $column[]=$vo;
        }
    }
    return $column;
}


//返回当前的毫秒时间戳
function mse_time() {
    list($mse, $sec) = explode(' ', microtime());
    return (float)sprintf('%.0f', (floatval($mse) + floatval($sec)) * 1000);
}


/**
 * @param $url
 * @param string $type
 * @param string $arr
 * @return mixed
 */
function http_curl($url,$type='get',$arr=''){
    //1.初始化curl
    $ch = curl_init();
    //2.设置curl的参数
    $header = array(
        'Accept: application/json, text/javascript, */*; q=0.01'
    );
    curl_setopt($ch, CURLOPT_HTTPHEADER,$header);

    if(strlen($url) > 5 && strtolower(substr($url,0,5)) == "https" ) {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    }

    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);  //将curl_exec()获取的信息以字符串返回，而不是直接输出。
    if ($type == 'post') {
        curl_setopt($ch,CURLOPT_POST,true);
        curl_setopt($ch,CURLOPT_POSTFIELDS,$arr);
    }
    //3.采集
    $output = curl_exec($ch);
    //4.关闭
    curl_close($ch);
    return $output;
}

/**
 * 生成32位随机数
 * @param $type(1为key,2位token)
 * @return string
 */
function getToken($type){
    $str="";
    switch ($type){
        case 1:
            $str= md5(uniqid(microtime(true),true));
            break;
        case 2:
            $str= md5(uniqid(mt_rand(), true));
            break;
    }
    return $str;
}

function getRandom(){
    $spe='';
    $et=mt_rand(1,2);
    switch ($et){
        case 1:
            $spe='+';
            break;
        case 2:
            $spe='-';
            break;
    }
    $a1=mt_rand(1,50);
    $a2=mt_rand(51,100);
    $sql=$a2.$spe.$a1."=";
    $res= $et==1 ? $a1+$a2 : $a2-$a1;
    return [
        'title'=>$sql,
        'res'=>$res
    ];
}

/**
 * 获取用户设备信息
 */
function equipmentSystem() {
    $agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    if (stristr($agent, 'iPad')) {
        $fb_fs = "iPad";
    } else if (preg_match('/Android (([0-9_.]{1,3})+)/i', $agent, $version)) {
        $fb_fs = "手机(Android " . $version[1] . ")";
    } else if (stristr($agent, 'Linux')) {
        $fb_fs = "电脑(Linux)";
    } else if (preg_match('/iPhone OS (([0-9_.]{1,3})+)/i', $agent, $version)) {
        $fb_fs = "手机(iPhone " . $version[1] . ")";
    } else if (preg_match('/Mac OS X (([0-9_.]{1,5})+)/i', $agent, $version)) {
        $fb_fs = "电脑(OS X " . $version[1] . ")";
    } else if (preg_match('/unix/i', $agent)) {
        $fb_fs = "Unix";
    } else if (preg_match('/windows/i', $agent)) {
        $fb_fs = "电脑(Windows)";
    } else {
        $fb_fs = "Unknown";
    }
    return $fb_fs;
}

/**
 * 生成定单号
 *
 */
function getOrderId(){
    return date('Ymd').substr(time(), -5).substr(
        microtime(), 2, 5).str_pad(mt_rand(1, 99), 2, '0', STR_PAD_LEFT);
}

/**
 * 文件命名
 */
function getFileIds()
{
    return date('ymd').substr(time(), -2).substr(
            microtime(), 2, 2).str_pad(mt_rand(1, 99), 2, '0', STR_PAD_LEFT);
}

/**
 *生成交易号
 */
function builderOrderSn($prefix = '')
{
    $prefix = !empty($prefix) ? $prefix : '';
    return  $prefix . date('Ymd').substr(microtime(), 2, 5).substr(implode(NULL,
            array_map('ord', str_split(substr(uniqid($prefix), 7, 13), 1))
        ), 0, 8). sprintf('%04d', rand(0, 9999));
}

function Mobile_Detect(){
    include_once 'Mobile_Detect.php';
    $detect = new Mobile_Detect();
    return $detect;
}


//手机端验证
function isMobile(){
    // 如果有HTTP_X_WAP_PROFILE则一定是移动设备
    if (isset ($_SERVER['HTTP_X_WAP_PROFILE'])) {
        return true;
    }

    //如果via信息含有wap则一定是移动设备,部分服务商会屏蔽该信息
    if (isset ($_SERVER['HTTP_VIA'])) {
        return stristr($_SERVER['HTTP_VIA'], "wap") ? true : false;
    }
//    判断手机发送的客户端标志,兼容性有待提高
    if (isset ($_SERVER['HTTP_USER_AGENT'])) {
        $clientkeywords = array('nokia', 'sony', 'ericsson', 'mot', 'samsung', 'htc', 'sgh', 'lg', 'sharp', 'sie-',
            'philips', 'panasonic', 'alcatel', 'lenovo', 'iphone', 'ipod', 'blackberry', 'meizu', 'android', 'netfront', 'symbian',
            'ucweb', 'windowsce', 'palm', 'operamini', 'operamobi', 'openwave', 'nexusone', 'cldc', 'midp', 'wap', 'mobile'
        );
        // 从HTTP_USER_AGENT中查找手机浏览器的关键字
        if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))) {
            return true;
        }
    }

//    if (isset ($_SERVER['HTTP_ACCEPT'])) {
//        // 如果只支持wml并且不支持html那一定是移动设备
//        // 如果支持wml和html但是wml在html之前则是移动设备
//        if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html')))) {
//            return true;
//        }
//    }
    return false;
}


/**
 * 生成二维码
 * @param  string  $url  url连接
 * @param  integer $size 尺寸 纯数字
 */
function scerweima($url='',$sort=1){
    Vendor('Phpqrcode.phpqrcode');
    $errorCorrectionLevel = 'L';  //容错级别
    $matrixPointSize = 5;      //生成图片大小
    //生成二维码图片
    $filename = 'Uploads/qrcode/wx/'.uniqid().'.png';
    QRcode::png($url,$filename,$errorCorrectionLevel, $matrixPointSize, 2);
    $QR = imagecreatefromstring(file_get_contents($filename));
    //输出图片
    imagepng($QR, 'qrcode.png');
//    imagedestroy($QR);
    $line=mainUrl.DS.$filename;
    if($sort==2){
        successReturn(200,'',$line);
    }
    echo "<img src='".$line."'>";
}


/**
 * 微信生成签名
 * @param  $data array
 * @return string
 */
function makeSign($data){
    // 去空
    $data=array_filter($data);      //array_unique去掉重复
    //签名步骤一：按字典序排序参数
    ksort($data);
    $string_a=http_build_query($data);  //将key=>value的数组转变为url字符串    parse_str函数则相反
    $string_a=urldecode($string_a);     //还原 URL 编码字符串
    //签名步骤二：在string后加入KEY
    //$config=$this->config;
//    $string_sign_temp=$string_a."&key=".$key;
    //签名步骤三：MD5加密
    $sign = md5($string_a);
    // 签名步骤四：所有字符转为大写
    $result=strtoupper($sign);        //strtolower 转为小写
    return $result;
}

/**
 * @param $type
 * @param $uid
 * @param array $str  //数组集合
 * @param $key1  //数量字段
 * @param $key2  //id集合字段
 * @return array
 */
//操作(点赞,转发)
function action($type,$uid,$str=array(),$key1,$key2){
    $data=array();
    switch ($type){
        case "off":
            if ($str[$key2] === null) {
                errorReturn(500, "不可进行该操作");
            } else {
                $arr = explode(',', $str[$key2]);
                if (array_search($uid, $arr)!==false && $str[$key1]!=0) {
                    array_splice($arr, array_search($uid, $arr), 1);   //移除指定元素
                    if($arr==null){
                        $data[$key2]=null;
                    }else{
                        $data[$key2] = implode(",", $arr);
                    }
                    //数量减
                    $str[$key1]-=1;
                    $data[$key1]= $str[$key1];
                    return $data;
                } else {
                    errorReturn(500, "不可进行该操作");
                }
            }
            break;

        case "on":
            //个人操作记录id集合
            if ($str[$key2] === null) {
                $data[$key2] = $uid;
            } else {
                $arr = explode(',', $str[$key2]);
                if (array_search($uid, $arr)!==false) {
                    errorReturn(500, '不可进行该操作');
                } else {
                    array_push($arr,$uid);
                    $data[$key2] = implode(",", $arr);
                }
            }
            //数量加
            $str[$key1]+=1;
            $data[$key1]= $str[$key1];
            break;
    }
    return $data;
}

//去除字符串所有空格
function trimAll($str){
    $before=array(" ","　","\t","\n","\r");
    $after=array("","","","","");
    $str=str_replace($before,$after,$str);
    return preg_replace("/(\s|\&nbsp\;|　|\xc2\xa0)/","",$str);
}

function randFloat($min = 0, $max = 1) {
    $rand = $min + mt_rand() / mt_getrandmax() * ($max - $min);
    return floatval(number_format($rand,2));
}


/**
 * 阿里云发送验证码
 * @method get
 * @param  type(1为注册登录，2为忘记密码)
 * @param  PhoneNumbers
 */
 function sendMsg($type,$PhoneNumbers){
    $code="";
    $pattern='1234567890';
    for($i=0;$i<6;$i++) {
        $code .= $pattern[mt_rand(0,9)];    //生成php随机数
    }
    $param['SignName']="育碧游戏";
    $param['PhoneNumbers']=$PhoneNumbers;
    switch($type){
        case 1:
            $param['TemplateCode']="SMS_219550059";
            break;
        case 2:
            $param['TemplateCode']="SMS_135530075";
    }
    Vendor('Aliyun.SendMsg');     //引用阿里云短信验证
    $msg = new \SendMsg();
    $response=$msg::sendSms($param,$code);
    $data['sendCode']=$code;
    $data['sendTime']=date("Ymd",time());
    $data['news']=$response;
    if($response){
        return $data;
    }
}

/**
 * 随机验证码
 */
function getRand(){
    return str_pad(mt_rand(0, pow(10, 6) - 1), 6, '0', STR_PAD_LEFT);
}


/**
 * @return array|false|string
 * 获取客户端的真实ip
 */
function getClientIP(){
    $ip = NULL;

    $keys = array(
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'REMOTE_ADDR'
    );

    foreach ($keys as $key) {
        if (!$ip && getenv($key) && strcasecmp(getenv($key), 'unknown')) {
            $ip = getenv($key);
        }
    }
    return $ip;
}

function getIp() {
    if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
        $ip = getenv('HTTP_CLIENT_IP');
    } elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    } elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
        $ip = getenv('REMOTE_ADDR');
    } elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    $res =  preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : '';
    return $res;
}

//参数加密签名
function makeSigns($data=[]){
    return Rsas::getInstance()->encode(http_build_query($data));
}

function desSigns($sign,$param=[]){
    $data = Rsas::getInstance()->decode($sign);
    //把查询字符串解析到变量中
    parse_str($data,$param);
    return $param;
}


//与前端aes 加解密
function base64Sign($type,$encrypted){
    $key = '1234567898765432';
    $iv = '1234567898765432';
    $res='';
    switch ($type){
        //加密
        case 1:
            $res= base64_encode(openssl_encrypt($encrypted,"AES-128-CBC",$key,OPENSSL_RAW_DATA,$iv));
            break;
        //解密
        case 2:
            $res= openssl_decrypt(base64_decode($encrypted), 'AES-128-CBC', $key,OPENSSL_RAW_DATA,$iv);
            break;
    }
    return $res;
}



/**
 * 密码加密和验证
 */
function pwdAct($type,$pwd,$check=""){
    switch ($type){
        case 1:
            return password_hash($pwd, PASSWORD_DEFAULT);
            break;
        case 2:
            return password_verify($pwd,$check);
            break;
    }
}


//极速数据第三方
function curlOpen($url, $config = array())
{
    $arr = array('post' => false,'referer' => $url,'cookie' => '', 'useragent' => 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; customie8)', 'timeout' => 20, 'return' => true, 'proxy' => '', 'userpwd' => '', 'nobody' => false,'header'=>array(),'gzip'=>true,'ssl'=>false,'isupfile'=>false);
    $arr = array_merge($arr, $config);
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, $arr['return']);
    curl_setopt($ch, CURLOPT_NOBODY, $arr['nobody']);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, $arr['useragent']);
    curl_setopt($ch, CURLOPT_REFERER, $arr['referer']);
    curl_setopt($ch, CURLOPT_TIMEOUT, $arr['timeout']);
    //curl_setopt($ch, CURLOPT_HEADER, true);//获取header
    if($arr['gzip']) curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
    if($arr['ssl'])
    {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    }
    if(!empty($arr['cookie']))
    {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $arr['cookie']);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $arr['cookie']);
    }

    if(!empty($arr['proxy']))
    {
        //curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
        curl_setopt ($ch, CURLOPT_PROXY, $arr['proxy']);
        if(!empty($arr['userpwd']))
        {
            curl_setopt($ch,CURLOPT_PROXYUSERPWD,$arr['userpwd']);
        }
    }

    //ip比较特殊，用键值表示
    if(!empty($arr['header']['ip']))
    {
        array_push($arr['header'],'X-FORWARDED-FOR:'.$arr['header']['ip'],'CLIENT-IP:'.$arr['header']['ip']);
        unset($arr['header']['ip']);
    }
    $arr['header'] = array_filter($arr['header']);

    if(!empty($arr['header']))
    {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $arr['header']);
    }

    if ($arr['post'] != false)
    {
        curl_setopt($ch, CURLOPT_POST, true);
        if(is_array($arr['post']) && $arr['isupfile'] === false)
        {
            $post = http_build_query($arr['post']);
        }
        else
        {
            $post = $arr['post'];
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    $result = curl_exec($ch);
    //var_dump(curl_getinfo($ch));
    curl_close($ch);

    return $result;
}

/**
 * 生成签名
 */
function getSign($queryarr, $appsecret)
{
    ksort($queryarr, SORT_STRING);
    $str = implode($queryarr);
    $str .= $appsecret;
    $str = md5($str);
    return $str;
}

/**
 * 获取小程序凭证
 */
function getTokens(){
    $param=[
        'appid'=>config('param.appid'),
        'secret'=>config('param.secret'),
        'grant_type'=>'client_credential'
    ];
    $url=config('param.tokenUrl')."?".http_build_query($param);
    $row=http_curl($url);
    $list=json_decode($row,true);
    if(isset($list['errcode']) && $list['errcode']!=0){
        return "deny";
    }else{
        return $list['access_token'];
    }
}

//时间解析
function parse($m,$type){
    if($type==1){
        return $m<10?'0'.$m:$m ;
    }else{
        if ($m>=10 && $m<100){
            return "0".$m;
        } elseif ($m<10 && $m>0){
            return "00".$m;
        } else{
            return $m;
        }
    }
}

//递归遍历文件夹
function recursionDir($dir){
    $result = [];
    $handle = opendir($dir);
    if ($handle) {
        while (($file = readdir($handle)) !== false) {
            if ($file != '.' && $file != '..') {
                $current_path = $dir . "/" . $file;
                if (is_dir($current_path)) {
                    $result['Directory'][$file] = recursionDir($current_path);
                } else {
                    $result['file'][] = $file;
                }
            }
        }
        closedir($handle);
    }
    return $result;
}











