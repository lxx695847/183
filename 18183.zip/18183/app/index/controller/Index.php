<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/19
 * Time: 10:27
 */
namespace app\Index\controller;
use think\Controller;
define("svp","http://".$_SERVER['HTTP_HOST']."/Uploads/");
header('content-type:application:json;charset=utf-8');
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods:OPTIONS, GET, POST'); // 允许option，get，post请求
header('Access-Control-Allow-Headers:Origin, X-Requested-With, Content-Type, Accept'); // 允许x-requested-with请求头

class Index extends Controller{
    public function index(){
        echo 'hello , ThinkPHP';
    }
}
