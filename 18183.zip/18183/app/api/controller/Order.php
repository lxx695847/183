<?php
namespace app\api\controller;
use think\Hook;
use think\Db;
use helper\weChat;

class Order extends Base{
    //获取accessToken
    public function getAccess($type){
        $config=config('companyWx');
        $secret="";$area="";
        switch ($type){
            case 1:
                $area='contact';
                $secret=$config['corpsecret_contact'];
                break;
            case 2:
                $area='apply';
                $secret=$config['corpsecret_apply'];
                break;
        }
        $token=cache($area);
        if($token!=false){
            return $token;
        }else{
            $url=$config['tokenUrl'].'?corpid='.$config['corpid'].'&corpsecret='.$secret;
            $data=http_curl($url);
            $row=json_decode($data,true);
            if($row['errcode']!=0){
                return false;
            }else{
                cache($area,$row['access_token'],$row['expires_in']);
                return $row['access_token'];
            }
        }
    }

    //获取部门
    public function getPartMent($type){
        $config=config('companyWx');
        $token=$this->getAccess(1);
        if($token!=false) {
            $url = $config['department'] . '?access_token=' . $token;
            $data = http_curl($url);
            $row = json_decode($data, true);
            if ($row['errcode'] != 0) {
                errorReturn($row['errcode'],$row['errmsg']);
            } else {
                switch ($type){
                    case 1:
                        //数据入库
                        $part=db('partment');
                        foreach ($row['department'] as $k=>$v){
                            $send=[
                               'id'=>$v['id'],
                               'name'=>$v['name'],
                               'order'=>$v['order'],
                               'pid'=>$v['parentid']
                            ];
                            $opt['id']=$v['id'];
                            $info=$part->where($opt)->find();
                            if(!$info){
                                $part->insert($send);
                            }
                        }
                        break;
                    case 2:
                        return [
                            'token'=>$token,
                            'partment'=>$row['department'],
                            'detailUrl'=>$config['PartMentUrl']
                        ];
                        break;
                }
            }
        }
    }

    //获取部门用户
    public function PartMentInfo($department_id=''){
        if($department_id){
            $config=config('companyWx');
            $token=$this->getAccess(1);
            $url = $config['PartMentUrl'] . '?access_token=' . $token . '&department_id='.$department_id;
            $data = http_curl($url);
            $rows = json_decode($data, true);
            if ($rows['errcode'] <= 0) {
                if (!empty($rows['userlist'])) {
                    $this->getPo($rows['userlist'],$token);
                }
            }
        }else{
            $row=$this->getPartMent(2);
            foreach ($row['partment'] as $k=>$v){
                $url = $row['detailUrl'] . '?access_token=' . $row['token'] . '&department_id='.$v['id'];
                $data = http_curl($url);
                $rows = json_decode($data, true);
                if ($rows['errcode'] <= 0) {
                    if (!empty($rows['userlist'])) {
                        $this->getPo($rows['userlist'],$row['token']);
                    }
                }
            }
        }
    }

    public function getPo($rows,$token){
        $user=db('user');
        $access=db('auth_group_access');
        foreach ($rows as $k=>$v){
            //用户数据入库
            $send=[
                'userid'=>$v['userid'],
                'name'=>$v['name'],
                'department'=>implode(',',$v['department']),
                'mobile'=>$v['mobile'],
                'gender'=>$v['gender'],
                'thumb_avatar'=>$v['thumb_avatar'],
                'status'=>$v['status']   //1=已激活，2=已禁用，4=未激活，5=退出企业。
            ];
            $openid=$this->getOpenid($token,$v['userid']);
            $send['openid']=$openid ? $openid : '';
            $opt['userid']=$v['userid'];
            $info=$user->where($opt)->find();
            if(!$info){
                $id=$user->insertGetId($send);
                if($id){
                    $os=[
                        'uid'=>$id,
                        'group_id'=>8
                    ];
                    $access->insert($os);
                }
            }
        }
    }

    //公众号开发
    public function getCheck(){
        $wechatObj = new weChat();
        if (!isset($_GET['echostr'])) {
            $wechatObj->responseMsg();
            //创建菜单
            $wechatObj->create_menu();
        }else{
            $wechatObj->valid();
        }
    }


    public function getRequest(){

    }

    public function getOpenid($token,$useid){
        $url = "https://qyapi.weixin.qq.com/cgi-bin/user/convert_to_openid?access_token=" . $token;
        $data = http_curl($url,'post',json_encode(['userid'=>$useid]));
        $row = json_decode($data, true);
        if ($row['errcode'] != 0) {
           return false;
        } else {
            return $row['openid'];
        }
    }

    //扫码登录
    public function login(){
        return view('Order/login');
    }

    //网页登录
    public function getUserInfo($code){
        $config=config('companyWx');
        $token=$this->getAccess(2);
        if($token!=false) {
            $url = $config['useInfo'] . '?access_token=' . $token . '&code='.$code;
            $data = http_curl($url);
            $row = json_decode($data, true);
            if ($row['errcode'] != 0) {
                errorReturn($row['errcode'],$row['errmsg']);
            } else {
               //获取用户信息
                $opt['userid']=$row['UserId'];
                $uid=db('user')->where($opt)->value('id');
                if($uid){
                    successReturn(200,'',$uid);
                }else{
                    errorReturn(1060,'请联系管理员确认用户信息');
                }
            }
        }else{
            errorReturn(1050,'参数错误');
        }
    }

    //礼包列表
    public function giftList(){
        $param=input('get.');
        $opt['id']=['gt',0];
        if(isset($param['gift'])){
            $opt['gift']=['like','%'.$param['gift'].'%'];
        }
        if(isset($param['order'])){
            $opt['order']=['like','%'.$param['order'].'%'];
        }
        if(isset($param['uid'])){
            $opt['uid']=$param['uid'];
        }
        if(isset($param['effect'])){
            $arr=explode('@',$param['effect']);
            $opt['effectStart']=['lt',strtotime($arr[1],time())];
            $opt['effectEnd']=['gt',strtotime($arr[0],time())];
        }
        //项目列表
        $list=db('product')->order('creat desc')->where($opt)->select();
        foreach ($list as $k=>$v){
            if($v['show']==2){
                if($v['effectEnd']<time()){
                    $list[$k]['status']=5; //已结束
                } elseif($v['effectStart']>time()){
                    $list[$k]['status']=4; //未开始
                } elseif($v['residue']<=0){
                    $list[$k]['status']=3;  //无库存
                }else{
                    $list[$k]['status']=2;  //发放中
                }
                $list[$k]['order']=strtoupper($v['order']);
            } else{
                $list[$k]['status']=1;  //已下架
            }
        }
        $row['list']=$list;
        $row['user']=db('user')->where(['status'=>1])->select();
        successReturn(200,'',$row);
    }


    //礼包上下架
    public function giftDelete(){
        $type=input('post.type');
        $id=input('post.id');
        $tag=[$type,$id];
        Hook::exec('app\\api\\behavior\\Check','run',$tag);
        $opt['id']=$id;
        $res=db('product')->where($opt)->setField('show',$type);
        check($res,3);
    }

    //礼包新增
    public function giftAdd(){
        $param=input('post.');
        $pro=db('product');
        $send=[
            'gift'=>$param['gift'],
            'order'=>$param['order'],
            'sort'=>$param['sort'],
            'uid'=>$param['uid'],
            'creat'=>time(),
            'show'=>$param['show'],
            'content'=>$param['content'],
            'info'=>isset($param['info']) ? $param['info'] : '',
            'extra'=>isset($param['extra']) ? $param['extra'] : '',
            'product'=>$param['product'],
            'frequency'=>$param['frequency'],
            'edit'=>time(),
            'isCheck'=>$param['isCheck']
        ];
        $order=$pro->column('order');
        if(in_array($param['order'],$order)){
            errorReturn('1060','该领取指令已存在，请更换指令');
        }
        $time=explode(',',$param['effect']);
        $send['effectStart']=strtotime($time[0],time());
        $send['effectEnd']=strtotime($time[1],time());
        $count=1;
        $secret=$param['secret'];
        if($param['sort']==2){
            $send['store']=$count;
            $send['residue']=$count;
        }else{
            $secret=explode('<>',$param['secret']);
            $count=count($secret);
            $send['store']=$count;
            $send['residue']=$count;
        }


        $id=$pro->insertGetId($send);
        if($id){
            $mySecret=db('secret');
            if($param['sort']==2){
                $data=[
                    'pid'=>$id,
                    'secret'=>$secret,
                    'receive'=>1
                ];
                $res=$mySecret->insert($data);
                check($res,1);
            }else{
                $data=[];
                $row=[
                    'pid'=>$id,
                    'receive'=>1
                ];
                for ($i=0;$i<$count;$i++){
                    $row['secret']=$secret[$i];
                    array_push($data,$row);
                }
                $res=$mySecret->insertAll($data);
                check($res,1);
            }
        }
    }

    public function giftEdit(){
        $pro=db('product');
        $mySecret=db('secret');
        if(request()->isGet()){
            $id=input('get.id');
            Hook::exec('app\\api\\behavior\\Check','run',$id);
            $res=$pro->alias('a')
                ->field('a.*,b.name')
                ->join('user b','a.uid=b.id')
                ->where(['a.id'=>$id])
                ->find();
            successReturn(200,'',$res);
        }else{
            $param=input('post.');
            $opt['id']=$param['id'];
            $info=$pro->field('store,residue')->where($opt)->find();
            $send=[
                'gift'=>$param['gift'],
                'order'=>$param['order'],
                'sort'=>$param['sort'],
                'show'=>$param['show'],
                'content'=>$param['content'],
                'info'=>isset($param['info']) ? $param['info'] : '',
                'extra'=>isset($param['extra']) ? $param['extra'] : '',
                'product'=>$param['product'],
                'frequency'=>$param['frequency'],
                'edit'=>time(),
                'isCheck'=>$param['isCheck']
            ];
            //是否有卡密录入
                if(isset($param['secret'])){
                    if($param['sort']==2){
                        $data=[
                            'pid'=>$param['id'],
                            'secret'=>$param['secret'],
                            'receive'=>1
                        ];
                        if($info['store']>0){
                                //替换
                               $opts['pid']=$param['id'];
                               $mySecret->where($opts)->update($data);
                        }else{
                                $mySecret->insert($data);
                                $send['store']=(int)$info['store']+1;
                                $send['residue']=(int)$info['residue']+1;
                        }
                    }else{
                        $secret=explode('<>',$param['secret']);
                        $count=count($secret);
                        $send['store']=(int)$info['store']+(int)$count;
                        $send['residue']=(int)$info['residue']+(int)$count;

                        $data=[];
                        $row=[
                            'pid'=>$param['id'],
                            'receive'=>1
                        ];
                        for ($i=0;$i<$count;$i++){
                            $row['secret']=$secret[$i];
                            array_push($data,$row);
                        }
                        $mySecret->insertAll($data);
                    }
                }
                $res=$pro->where($opt)->update($send);
                check($res,2);
        }
    }

    //卡密详情
    public function cardDetail(){
        $pid=input('get.pid');
        Hook::exec('app\\api\\behavior\\Check','run',$pid);
        $secret=db('secret');
        $opt=['pid'=>$pid];
        $sort=db('product')->where(['id'=>$pid])->value('sort');
        if($sort==2){
            $tp=db('record')->alias('a')
                ->field('a.openid,a.receiveTime,a.ip,a.receive,b.id,b.secret')
                ->join('secret b','a.sid=b.id')
                ->where(['a.pid'=>$pid])
                ->order('a.receiveTime desc')
                ->select();
            if($tp){
                $res=$tp;
            }else{
                $res=$secret->where($opt)->order('receiveTime desc')->select();
            }
        }else{
            $res=$secret->where($opt)->order('receiveTime desc')->select();
        }
        successReturn(200,'',$res);
    }

    //卡密删除
    public function cardDelete(){
        $type=input('post.type');
        $id=input('post.id');
        $pid=input('post.pid');
        $tag=[$type,$id,$pid];
        Hook::exec('app\\api\\behavior\\Check','run',$tag);
        $pro=db('product');
        switch ($type){
            case 1:
                $opt['id']=$id;
                $opts['id']=$pid;
                Db::startTrans();
                try {
                    db('secret')->where($opt)->delete();
                    $pro->where($opts)->setDec('store');
                    $pro->where($opts)->setDec('residue');
                    Db::commit();
                    successReturn(203);
                }catch (\Exception $e) {
                    // 回滚事务
                    Db::rollback();
                    errorReturn(405,$e->getMessage());
                }
                break;
            case 2:
                break;
        }
    }

    /**
     * 参数修改
     */
    public function setConfig(){
        if(request()->isGet()){
            $row=db('base')->find();
            successReturn(200,'',$row);
        }else{
            $param=input('post.');
            $res=db('base')->where(['id'=>1])->update($param);
            check($res,2);
        }
    }
}