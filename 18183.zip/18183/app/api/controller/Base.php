<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/15
 * Time: 16:27
 */
//基类
namespace app\api\controller;
use think\Controller;
header('content-type:application:json;charset=utf-8');
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods:OPTIONS, GET, POST'); // 允许option，get，post请求
header('Access-Control-Allow-Headers:Origin, X-Requested-With, Content-Type, Accept'); // 允许x-requested-with请求头

class Base extends Controller{
//        //行为标签
//        Hook::exec('app\\api\\behavior\\check', 'run', $user);
    public function __construct() {}

    //空方法
    public function _empty(){
        errorReturn(500,"该请求方法不存在,请先检查!");
    }


    /**
     * 获取的参数值
     * @param $array 参数键名数组
     * @return array 返回数据数组
     */
    protected function buildParam($array){
        $data=[];
        if (is_array($array)){
            foreach( $array as $k=>$v ){
                $data[$v] = $this->request->param($v);
            }
        }
        return $data;
    }
}