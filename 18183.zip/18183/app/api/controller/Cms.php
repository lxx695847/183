<?php
namespace app\api\controller;
use think\Hook;
use think\Auth;

class Cms extends Base{
    //用户以及权限管理
    public function getUsers(){
        $opt['id']=['gt',0];
        $param=input('get.');
        //手机号
        if(isset($param['mobile']) && $param['mobile']!=false){
            $opt['mobile']=['like','%'.$param['mobile'].'%'];
        }

        //部门
        if(isset($param['pid']) && $param['pid']!=false){
            $opt['pid']=$param['pid'];
        }

        //状态
        if(isset($param['status']) && $param['status']!=false){
            $opt['status']=$param['status'];
        }

        $auth=new Auth();
        $user=db('user')->where($opt)->select();
        if($user){
            foreach ($user as $k=>$v){
                $group=$auth->getGroups($v['id']);
                if(!empty($group)){
                    foreach ($group as $ks=>$vs){
                        $user[$k]['group']=$vs['title'];
                        $user[$k]['groupId']=$vs['id'];
                        $user[$k]['assign']=$vs['base']==3 ? false : true;  //不可分配其他组
                    }
                }
            }
        }

        //部门
        $part=db('partment')->field('id,name,pid')->select();

        //用户组
        $res['group']=db('auth_group')->field('id,title')->select();
        $res['partment']=$part;
        $res['user']=$user;
        successReturn(200,'',$res);
    }

    //权限组
    public function getGroups(){
        $group=db('auth_group')->select();
        successReturn(200,'',$group);
    }

    //分配用户权限组
    public function userRole(){
        $uid=input('post.uid');
        $groupId=input('post.groupId');
        $tag=[$uid,$groupId];
        Hook::exec('app\\api\\behavior\\Check','run',$tag);
        $res=db('auth_group_access')->where(['uid'=>$uid])->setField('group_id',$groupId);
        check($res,2);
    }

    //权限组权限
    public function watch_auth(){
        $group_id=input('get.group_id');
        $checks=[];
        $rule=db('auth_rule');
        $hide=$rule->where(['is_hide'=>2])->column('id');
        if($group_id){
            $opt['id']=$group_id;
            $rules=db('auth_group')->where($opt)->value('rules');
            if($rules){
                $checks=explode(",",$rules);
                foreach ($checks as $k=>$v){
                    if(in_array($v,$hide)){
                        unset($checks[$k]);
                    }else{
                        $checks[$k]=(int)$v;
                    }
                }
            }
        }

        $row=$rule->field('id,pid,title')->where(['is_hide'=>1])->select();
        $arr=get_menu($row);
        $po=[];
        foreach ($arr as $ks=>$vs){
            $po[$ks]['title']=$vs['title'];
            $po[$ks]['key']=$vs['id'];
            if(!empty($vs['sub'])){
                foreach ($vs['sub'] as $kk=>$vv){
                    $po[$ks]['children'][$kk]=[
                        'title'=>$vv['title'],
                        'key'=>$vv['id']
                    ];
                }
            }
        }
        successReturn(200,'',[
            'rule'=>$checks,
            'list'=>$po
        ]);
    }

    public function edit_auth(){
        $type=input('post.type');
        Hook::exec('app\\api\\behavior\\Check','run',$type);
        $group=db('auth_group');
        $param=input('post.');
        switch ($type){
            case 1:
                $gid=input('post.gid');
                Hook::exec('app\\api\\behavior\\Check','run',$gid);
                $send=[
                    'title'=>$param['title'],
                    'rules'=>$param['rules']
                ];
                $res=$group->where(['id'=>$gid])->update($send);
                check($res,2);
                break;
            case 2:
                $send=[
                    'title'=>$param['title'],
                    'rules'=>$param['rules'],
                    'base'=>$param['base']
                ];
                $res=$group->insert($send);
                check($res,1);
                break;
        }
    }

    /**
     * 账户信息
     */
    public function currentUser(){
        $uid=input('post.uid');
        Hook::exec('app\\api\\behavior\\Check','run',$uid);
        $info=db('user')->where(['id'=>$uid])->find();
        $group=(new Auth())->getGroups($info['id']);
        //角色
        $role=[
            'is_action'=>false,
            'is_delete'=>false,
            'is_assign'=>false,
        ];
        if(!empty($group)){
            foreach ($group as $v){
                $info['base']=$v['base'];
                switch ($v['base']){
                    case 1:
                        $info['role']=$role;
                        break;
                    case 2:
                        $role['is_action']=true;
                        $info['role']=$role;
                        break;
                    case 3:
                        $info['role']=[
                            'is_action'=>true,
                            'is_delete'=>true,
                            'is_assign'=>true,
                        ];
                        break;
                    default:
                        $info['role']=$role;
                        break;
                }
            }
        }else{
            $info['role']=$role;
        }
        if($info){
            successReturn(200,'',$info);
        }else{
            errorReturn('当前用户不存在');
        }
    }

    /**
     * 菜单管理
     */
    public function menuData(){
        $uid=input('post.uid');
        Hook::exec('app\\api\\behavior\\Check','run',$uid);
        $res=db('auth_group_access')
            ->alias('a')
            ->field('b.rules')
            ->join('auth_group b','a.group_id=b.id')
            ->where(['a.uid'=>$uid])
            ->find();
        if($res){
            $opt['id']=['in',explode(',',$res['rules'])];
            $row=db('auth_rule')->where($opt)->select();
            $new_menu=get_menu($row);

            $arr=[];$first=[];
            foreach ($new_menu as $k=>$v){
                $arr[$k]=[
                    'name'=>$v['short'],
                    'icon'=>$v['icon'],
                    'path'=>$v['route'],
                    'routes'=>[]
                ];
                foreach ($v['sub'] as $ks=>$vs){
                    if(empty($vs['sub'])){
                        if($vs['is_first']==2){
                            $first=[
                                'path'=>'/',
                                'redirect'=>$vs['route'],
                            ];
                        }
                        $list=[
                            'name'=>$vs['short'],
                            'icon'=>$vs['icon'],
                            'path'=>$vs['route'],
                            'component'=>".".$vs['route'],
                        ];

                        if($vs['is_hide']==2){
                            $list['hideInMenu']=true;
                        }
                        array_push($arr[$k]['routes'],$list);

                        if($vs['subIns']==2) {
                            $send = [
                                'path' => $v['route'],
                                'redirect' => $vs['route']
                            ];
                            array_unshift($arr[$k]['routes'],$send);
                        }
                    }else{
                        $arr[$k]['routes'][$ks]=[
                            'name'=>$vs['short'],
                            'icon'=>$vs['icon'],
                            'path'=>$vs['route'],
                            'routes'=>[]
                        ];
                        foreach ($vs['sub'] as $kk=>$vv){
                            $lists=[
                                'name'=>$vv['short'],
                                'icon'=>$vv['icon'],
                                'path'=>$vv['route'],
                                'component'=>".".$vv['route']
                            ];
                            if($vv['is_hide']==2){
                                $lists['hideInMenu']=true;
                            }
                            array_push($arr[$k]['routes'][$ks]['routes'],$lists);
                            if($vv['subIns']==2) {
                                $send = [
                                    'path' => $vs['route'],
                                    'redirect' => $vv['route']
                                ];
                                array_unshift($arr[$k]['routes'][$ks]['routes'],$send);
                            }
                        }
                    }
                }
            }

            foreach ($new_menu as $k=>$v){
                foreach ($v['sub'] as $ks=>$vs){
                    if(!empty($vs['sub'])){
                        if($vs['firstIns']==2) {
                            foreach ($vs['sub'] as $kk=>$vv){
                                if($vv['subIns']==2) {
                                    $send = [
                                        'path' => $v['route'],
                                        'redirect' => $vv['route']
                                    ];
                                    array_unshift($arr[$k]['routes'],$send);
                                }
                            }
                        }
                    }
                }
            }

            //登录
            $login=[
                'path'=> '/user',
                'layout'=> false,
                'routes'=>[
                    [
                        'path'=> '/user',
                        'redirect'=> '/user/login'
                    ],
                    [
                        'path'=> '/user/login',
                        'layout'=> false,
                        'name'=> 'login',
                        'component'=> './user/Login',
                    ]
                ]
            ];
            $end=[
                'component'=> '404',
            ];
            array_unshift($arr,$login);
            array_push($arr,$first);
            array_push($arr,$end);
            successReturn(200,'',$arr);
        }else{
            successReturn(204);
        }
    }

}