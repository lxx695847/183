<?php
namespace app\api\controller;
use think\Hook;
use encrypt\WXBizDataCrypt;
use think\captcha\Captcha;

class Login extends Base{
    //获取openid
    public function getAccess(){
        $param=input("post.");
        $url="https://api.weixin.qq.com/sns/jscode2session?".http_build_query($param);
        $row=http_curl($url);
        $list=json_decode($row,true);
        if(isset($list['errcode']) && $list['errcode']!=0){
            errorReturn($list['errcode'],$list['errmsg']);
        }else{
            successReturn(200,"",$list);
        }
    }

    public function getAccessToken(){
        $config=config('wxProject');
        $token=cache('project');
        if($token!=false){
            return $token;
        }else{
            $url=$config['tokenUrl'].'?grant_type=client_credential&appid='.$config['APPID'].'&secret='.$config['SECRET'];
            $data=http_curl($url);
            $row=json_decode($data,true);
            if($row['errcode']!=0){
                return false;
            }else{
                cache('project',$row['access_token'],$row['expires_in']);
                return $row['access_token'];
            }
        }
    }

    //新版api
    public function getPhone(){
        $code=input('get.code');
        Hook::exec('app\\api\\behavior\\Check','run',$code);
        $config=config('wxProject');
        $token=$this->getAccessToken();
        if($token){
            $url=$config['phoneUrl']."?access_token=".$token;
            $send=json_encode([
                'access_token'=>$token,
                'code'=>$code
            ]);
            $data=http_curl($url,'post',$send);
            $row=json_decode($data,true);
            if($row['errcode']!=0){
                errorReturn($row['errcode'],$row['errmsg']);
            }else{
                successReturn(200,'',$row['phone_info']['phoneNumber']);
            }
        }else{
            errorReturn(1005,'参数错误');
        }
    }

    //旧版api
    /**
     * 微信小程序手机号授权
     */
    public function getPhones(){
        $iv=input("post.iv");
        $encrypt=input('post.encrypt');
        $appid=input('post.appid');
        $session_key=stripslashes(input('post.session_key'));
        $tag=[$iv,$encrypt,$appid,$session_key];
        Hook::exec('app\\api\\behavior\\Check','run',$tag);
        $pc = new WXBizDataCrypt($appid, $session_key);
        $errCode = $pc->decryptData($encrypt, $iv, $data );
        if ($errCode == 0) {
            successReturn(200,'',$data);
        } else {
            errorReturn($errCode,"数据解密失败");
        }
    }

    //图形验证码
    public function getCode(){
        $captcha = new captcha();
        return $captcha->entry();
    }

    public function getTest(){
        return getIp();
    }
}