<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/7/17
 * Time: 15:08
 */
namespace app\api\behavior;

class Check{
//参数判断
     public function run(&$params){
         if($params == false){
             errorReturn(400);
         }else{
             if(is_array($params)){
                 foreach ($params as $val){
                     if(!$val){
                         errorReturn(400);
                     }
                 }
             }else if(is_string($params)){
                 if($params == false){
                     errorReturn(400);
                 }
             }else{
                 errorReturn(500,"暂不支持该类型的检测");
             }
         }
    }

    //模块开关
    public function checkModel(&$opt){
         $system=db('system')->where(['id'=>1])->find();
         if($system[$opt]==1){
             errorReturn(2001,"活动更新中，请稍后再试");
         }
    }

    //根据参数结果判断
    public function result(&$arr){
        foreach ($arr as $val){
            if(!$val){
                errorReturn(1012,"查询参数错误");
            }
        }
    }

  //接口凭证验证
    public function checkAccess(&$info){
         if($info==false){
             errorReturn(1001,"接口凭证缺失，请检验");
         }elseif (is_array($info)==false){
             errorReturn(1003,"接口凭证结构错误，请检验");
         } else{
               $opt=[];$option=[];
               switch ($info['type']){
                   case 'access':
                       $opt=['token','uid','oauth'];
                       $option=[
                           'id'=>$info['uid'],
                           'token'=>$info['token']
                       ];
                       break;
                   case 'sign':  //任务1、里程碑领取签名3
                       $opt=['actToken','uid','id','act','model'];
                       $option=['id'=>$info['uid']];
                       break;

                   case 'pass':  //抽奖签名2,育碧绑定4
                       $opt=['actToken','uid','act','model'];
                       $option=['id'=>$info['uid']];
                       break;

                   case 'import':  //微信授权相关签名
                       $opt=['openid','act','actToken'];
                       break;
               }

               if($info['type']!='import'){
                   $res=db('login')->where($option)->find();
                   if($res==false){
                       errorReturn(1008,"签名参数过期或错误，请重新登录");
                   }else{
                       if($res['status']==1){
                           errorReturn(1005,"用户状态异常，请联系客服");
                       }
                   }
               }

               foreach ($opt as $k=>$v){
                   if(!isset($info[$v]) && $info[$v]==false){
                       errorReturn(1007,"签名参数缺失，请检验");
                   }
               }
         }
    }
}